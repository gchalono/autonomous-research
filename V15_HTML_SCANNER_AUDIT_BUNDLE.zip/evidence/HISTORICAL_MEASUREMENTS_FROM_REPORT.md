| Family | Bytes/chars | Original CPU median s | V15 CPU median s | Original traced peak bytes | V15 traced peak bytes | V15 status |
|---|---:|---:|---:|---:|---:|---|
| script | 4096 / 4096 | 0.008000312 | 0.000006649 | 9391 | 6232 | completed |
| script | 8192 / 8192 | 0.034669612 | 0.000009370 | 18127 | 10328 | completed |
| script | 16384 / 16384 | 0.127994161 | 0.000015029 | 36690 | 18520 | completed |
| script | 32768 / 32768 | 0.548002660 | 0.000025354 | 69938 | 34904 | completed |
| script | 262144 / 262144 | NOT RUN | 0.000183923 | NOT RUN | 264280 | completed |
| script | 1048576 / 1048576 | NOT RUN | 0.000693377 | NOT RUN | 1050712 | completed |
| script | 4194304 / 4194304 | NOT RUN | 0.002956837 | NOT RUN | 4196440 | completed |
| style | 4096 / 4096 | 0.009334090 | 0.000008166 | 9967 | 6231 | completed |
| style | 8192 / 8192 | 0.036001970 | 0.000010246 | 19441 | 10327 | completed |
| style | 16384 / 16384 | 0.152026968 | 0.000017131 | 39335 | 18519 | completed |
| style | 32768 / 32768 | 0.604021187 | 0.000030519 | 79356 | 34903 | completed |
| style | 262144 / 262144 | NOT RUN | 0.000206734 | NOT RUN | 264279 | completed |
| style | 1048576 / 1048576 | NOT RUN | 0.000897081 | NOT RUN | 1050711 | completed |
| style | 4194304 / 4194304 | NOT RUN | 0.003385344 | NOT RUN | 4196439 | completed |
| alternating | 4096 / 4096 | 0.008397178 | 0.000008152 | 9967 | 6232 | completed |
| alternating | 8192 / 8192 | 0.036002024 | 0.000013545 | 18211 | 10328 | completed |
| alternating | 16384 / 16384 | 0.135918560 | 0.000017267 | 36875 | 18520 | completed |
| alternating | 32768 / 32768 | 0.572018285 | 0.000035957 | 74371 | 34904 | completed |
| alternating | 262144 / 262144 | NOT RUN | 0.000207228 | NOT RUN | 264280 | completed |
| alternating | 1048576 / 1048576 | NOT RUN | 0.000823461 | NOT RUN | 1050712 | completed |
| alternating | 4194304 / 4194304 | NOT RUN | 0.003111331 | NOT RUN | 4196393 | completed |
| malformed | 4096 / 4096 | 0.003066474 | 0.000003990 | 90041 | 6165 | ValueError |
| malformed | 8192 / 8192 | 0.010500657 | 0.000003829 | 181003 | 10261 | ValueError |
| malformed | 16384 / 16384 | 0.044002234 | 0.000004540 | 363481 | 18485 | ValueError |
| malformed | 32768 / 32768 | 0.160005700 | 0.000007036 | 729931 | 34869 | ValueError |
| malformed | 262144 / 262144 | NOT RUN | 0.000024868 | NOT RUN | 264245 | ValueError |
| malformed | 1048576 / 1048576 | NOT RUN | 0.000092470 | NOT RUN | 1050677 | ValueError |
| malformed | 4194304 / 4194304 | NOT RUN | 0.000417103 | NOT RUN | 4196405 | ValueError |
| openings | 4096 / 4096 | 0.000104386 | 0.002782773 | 16776 | 6534 | completed |
| openings | 8192 / 8192 | 0.000245618 | 0.005428795 | 34121 | 10641 | ValueError |
| openings | 16384 / 16384 | 0.000474596 | 0.011500803 | 69032 | 18869 | completed |
| openings | 32768 / 32768 | 0.000955258 | 0.022999237 | 139625 | 35170 | ValueError |
| openings | 262144 / 262144 | NOT RUN | 0.176002041 | NOT RUN | 264830 | completed |
| openings | 1048576 / 1048576 | NOT RUN | 0.759996716 | NOT RUN | 1051309 | completed |
| openings | 4194304 / 4194304 | NOT RUN | 3.387259348 | NOT RUN | 4196943 | completed |
| benign | 4096 / 4096 | 0.000162685 | 0.001423647 | 33354 | 31377 | completed |
| benign | 8192 / 8192 | 0.000308869 | 0.003172630 | 65102 | 60505 | completed |
| benign | 16384 / 16384 | 0.000604655 | 0.005714905 | 130779 | 120984 | completed |
| benign | 32768 / 32768 | 0.001237056 | 0.008400206 | 262613 | 173849 | completed |
| benign | 262144 / 262144 | NOT RUN | 0.044002513 | NOT RUN | 407497 | completed |
| benign | 1048576 / 1048576 | NOT RUN | 0.167984545 | NOT RUN | 1191542 | completed |
| benign | 4194304 / 4194304 | NOT RUN | 0.696004490 | NOT RUN | 4335774 | completed |
| title | 4096 / 4096 | 0.010500564 | 0.001802617 | 9967 | 6523 | completed |
| title | 8192 / 8192 | 0.044001918 | 0.003407508 | 19441 | 10645 | ValueError |
| title | 16384 / 16384 | 0.167947680 | 0.007000043 | 39335 | 18792 | ValueError |
| title | 32768 / 32768 | 0.751591191 | 0.013295937 | 79356 | 35195 | completed |
| title | 262144 / 262144 | NOT RUN | 0.108005414 | NOT RUN | 264866 | completed |
| wideunicode | 4194304 / 4194301 | 0.088002898 | 0.056003176 | 20971621 | 20971621 | completed |

### Adjacent-size observed ratios

- script before: 4096→8192: size×2, CPU×4.334; 8192→16384: size×2, CPU×3.692; 16384→32768: size×2, CPU×4.281.
- script after: 4096→8192: size×2, CPU×1.409; 8192→16384: size×2, CPU×1.604; 16384→32768: size×2, CPU×1.687; 32768→262144: size×8, CPU×7.254; 262144→1048576: size×4, CPU×3.770; 1048576→4194304: size×4, CPU×4.264.
- style before: 4096→8192: size×2, CPU×3.857; 8192→16384: size×2, CPU×4.223; 16384→32768: size×2, CPU×3.973.
- style after: 4096→8192: size×2, CPU×1.255; 8192→16384: size×2, CPU×1.672; 16384→32768: size×2, CPU×1.781; 32768→262144: size×8, CPU×6.774; 262144→1048576: size×4, CPU×4.339; 1048576→4194304: size×4, CPU×3.774.
- alternating before: 4096→8192: size×2, CPU×4.287; 8192→16384: size×2, CPU×3.775; 16384→32768: size×2, CPU×4.209.
- alternating after: 4096→8192: size×2, CPU×1.662; 8192→16384: size×2, CPU×1.275; 16384→32768: size×2, CPU×2.082; 32768→262144: size×8, CPU×5.763; 262144→1048576: size×4, CPU×3.974; 1048576→4194304: size×4, CPU×3.778.
- malformed before: 4096→8192: size×2, CPU×3.424; 8192→16384: size×2, CPU×4.190; 16384→32768: size×2, CPU×3.636.
- malformed after: 4096→8192: size×2, CPU×0.960; 8192→16384: size×2, CPU×1.186; 16384→32768: size×2, CPU×1.550; 32768→262144: size×8, CPU×3.535; 262144→1048576: size×4, CPU×3.718; 1048576→4194304: size×4, CPU×4.511.
- openings before: 4096→8192: size×2, CPU×2.353; 8192→16384: size×2, CPU×1.932; 16384→32768: size×2, CPU×2.013.
- openings after: 4096→8192: size×2, CPU×1.951; 8192→16384: size×2, CPU×2.118; 16384→32768: size×2, CPU×2.000; 32768→262144: size×8, CPU×7.653; 262144→1048576: size×4, CPU×4.318; 1048576→4194304: size×4, CPU×4.457.
- benign before: 4096→8192: size×2, CPU×1.899; 8192→16384: size×2, CPU×1.958; 16384→32768: size×2, CPU×2.046.
- benign after: 4096→8192: size×2, CPU×2.229; 8192→16384: size×2, CPU×1.801; 16384→32768: size×2, CPU×1.470; 32768→262144: size×8, CPU×5.238; 262144→1048576: size×4, CPU×3.818; 1048576→4194304: size×4, CPU×4.143.
- title before: 4096→8192: size×2, CPU×4.190; 8192→16384: size×2, CPU×3.817; 16384→32768: size×2, CPU×4.475.
- title after: 4096→8192: size×2, CPU×1.890; 8192→16384: size×2, CPU×2.054; 16384→32768: size×2, CPU×1.899; 32768→262144: size×8, CPU×8.123.

Interpretation: baseline script/style/alternating/malformed/title doublings cluster around ~4×. Known raw script/style paths now scan approximately linearly; malformed tags reject early, plus one bounded full UTF-8 decode, rather than reproducing quadratic completion. Larger after-only sizes reach the full 4MiB limit for three required malicious families and controls. Repeated ordinary tags at 4MiB cost ~3.4s CPU, with roughly proportional scaling, and benign HTML at 4MiB ~0.7s; these higher constants are documented, not hidden behind only fast malicious examples. At 32KiB benign pages remain around milliseconds, but are slower than the original C-heavy substitutions. Title extra family is measured through 256KiB; maximum-size single-title retention tested separately. No comparable quadratic pattern found in tested malformed families. This supports the forward-scan argument; it does not establish a hard total CPU deadline or prove every possible Python/runtime worst case.

