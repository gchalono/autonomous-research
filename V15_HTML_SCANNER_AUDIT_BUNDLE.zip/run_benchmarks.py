from pathlib import Path
import sys,os,subprocess,argparse,json,hashlib
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--extended',action='store_true');a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
small=[4096,8192,16384,32768];jobs=[]
for f in ['script','style','alternating','malformed','openings','benign','title']:
 for mode in ['before','after']:
  sizes=small if mode=='before' else small+([262144,1048576,4194304] if f!='title' else [262144])
  if not a.extended:sizes=small if mode=='before' else small+([4194304] if f in ('script','style','malformed','benign') else [])
  jobs.extend((mode,f,n) for n in sizes)
jobs.extend((m,'wideunicode',4194304) for m in ['before','after'])
for mode,f,n in jobs:
 env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
 env.update(PYTHONPATH=str(root/'offline_guard'),PYTHONDONTWRITEBYTECODE='1',AUDIT_WORK_ROOT=str(out),AUDIT_IMMUTABLE_ROOT=str(root),AUDIT_PROTECTED_REPO='')
 log=out/f'{mode}_{f}_{n}.log'
 with log.open('w') as stream:
  try:r=subprocess.run([sys.executable,str(root/'benchmark_one.py'),mode,f,str(n),str(out/f'{mode}_{f}_{n}.json')],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=90);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 if code:print('FAILED',mode,f,n,code);raise SystemExit(code)
 print(log.read_text().strip(),flush=True)
