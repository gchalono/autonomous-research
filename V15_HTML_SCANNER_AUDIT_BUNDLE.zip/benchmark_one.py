"""Packaging-time reconstruction of the documented V15 benchmark protocol."""
from pathlib import Path
import sys,time,statistics,tracemalloc,platform,math,importlib.util,json,resource
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'baseline_repository'))
mode,family,size,out=sys.argv[1:];size=int(size);out=Path(out)
resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
body=(root/'inputs'/f'{family}_{size}.html').read_bytes()
source=root/('baseline_repository' if mode=='before' else 'current')/'src/tools/retrieval.py'
spec=importlib.util.spec_from_file_location('src.tools.benchmark_retrieval',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.read_public_url=lambda url:body
# No networking/setup in timed regions; actual production fetch/decode/extraction.
def invoke():
 try:
  title,text=module.fetch_url('https://offline.invalid');return {'status':'completed','title_chars':len(title),'text_chars':len(text)}
 except ValueError as e:return {'status':type(e).__name__,'message':str(e)}
invoke();start=time.perf_counter();invoke();pilot=time.perf_counter()-start;batch=max(1,min(50000,math.ceil(.08/max(pilot,1e-7))))
cpu=[];wall=[]
for rep in range(3):
 t=time.process_time();w=time.perf_counter()
 for _ in range(batch):result=invoke()
 cpu.append((time.process_time()-t)/batch);wall.append((time.perf_counter()-w)/batch)
tracemalloc.start();invoke();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps({'provenance':'fresh packaging replay; not a recovered historical raw log','mode':mode,'family':family,'input_file':str((root/'inputs'/f'{family}_{size}.html').relative_to(root)),'input_bytes':len(body),'input_chars':len(body.decode()),'cpu_median':statistics.median(cpu),'cpu_range':[min(cpu),max(cpu)],'wall_median':statistics.median(wall),'wall_range':[min(wall),max(wall)],'tracemalloc_peak':peak,'tracemalloc_current':current,'result':result,'repetitions':3,'iterations_per_repetition':batch,'python':sys.version,'platform':platform.platform(),'memory_note':'Separate untimed traced invocation, excluding prebuilt input bytes and native allocations; no extra original fixture Unicode string retained.'},indent=2))
print(mode,family,size,statistics.median(cpu),peak,flush=True)
