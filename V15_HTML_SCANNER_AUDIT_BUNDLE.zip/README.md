# V15 HTML scanner independent audit

Exact repository: gchalono/autonomous-research; working branch policy-validator-repair; committed V14 baseline d52378c18342494754b40504b4af51b3cefbcdd7. Complete V15 change is retrieval.py plus new test/report. No V15 source commit/push is authorized by this package; only the ZIP belongs on the audit branch.

## Contents and integrity
V15_COMPLETE.patch includes all three changed/new paths. current/ preserves exact repository-relative files; baseline_original/ is original retrieval.py. baseline_repository/ includes all baseline tracked runtime, tests, fixtures, audits, dependency and pytest configuration, except .env.example deliberately omitted. No real env, credentials, databases, cache or Git objects. BASELINE_STATE_MANIFEST and MODIFIED_STATE_MANIFEST cover full baseline/modified state metadata; omitted template hash is metadata only. CHANGES.json identifies exact scope and hashes. MANIFEST.json hashes every payload file including state manifests; MANIFEST.sha256 authenticates that manifest (the seal cannot self-list). External archive SHA-256 covers both seal entries too.

inputs/ contains exact finite benchmark bytes with generator descriptions, lengths and SHA-256 in INPUT_MANIFEST.json. Input strings repeat/truncate the documented patterns, with the 4MiB mixed-width UTF-8 fixture separately defined. Production fetch_url executes in replay; not scanner-only tests.

## Important provenance limitation
The original temporary raw benchmark/test logs and scripts did not survive workspace refresh. The original report is unchanged, and its historical table/ratios are separately preserved verbatim. No missing CPU ranges/wall samples have been invented. Packaging-time benchmark scripts reconstruct the documented protocol and exact deterministic inputs; fresh replay evidence is labeled separately. See evidence/PROVENANCE.md. Muse should compare historical claims with independent replay, not treat reconstructed scripts as signed historical bytes.

## Portable offline replay
Use an existing Linux Python environment with dependencies compatible with environment.json; no network install. Extract to a disposable directory. The runner verifies manifests, copies the bundled full baseline, applies the patch, verifies hashes, runs in temporary files with credential-free Python socket/DNS audit guard, and preserves output without fixture DBs. All full-suite source/fixtures are supplied; no external checkout or fetch is required. Optional --full-repository CHECKOUT uses git archive of the exact baseline, never current/uncommitted files. Use --protect-repository CHECKOUT to explicitly protect a caller checkout while testing only the bundled baseline; packaging full replay used that mode.

```
/path/to/python run_offline.py html --output /tmp/v15-audit/html
/path/to/python run_offline.py ssrf --output /tmp/v15-audit/ssrf
/path/to/python run_offline.py bounded --output /tmp/v15-audit/bounded
/path/to/python run_offline.py fetch --output /tmp/v15-audit/fetch
/path/to/python run_offline.py tools --output /tmp/v15-audit/tools
/path/to/python run_offline.py full --output /tmp/v15-audit/full
/path/to/python run_benchmarks.py --output /tmp/v15-audit/benchmarks
/path/to/python run_benchmarks.py --extended --output /tmp/v15-audit/extended-benchmarks
```

Expected test reference: html43, SSRF54, bounded43, fetch1, tools23; full477 passing, 2 documented V5 skips, 1 paid test deselected. Groups overlap. Native V6 writes permitted only in disposable evidence locations; original and snapshot source/canonical policy/ledger protected. Guard applies to spawned Python; use OS network isolation too when auditing untrusted code. Output retains full logs, per-phase census, resource measurements and native audit JSON. No assertion is monkeypatched to pass, no failures suppressed.

Benchmarks load exact baseline/current production fetch_url with the network read replaced by finite input bytes. Credentials stripped and socket/DNS denied. One warmup, pilot, three calibrated batches targeting 80ms wall; per-invocation CPU/process_time and wall/perf_counter median/range, separate untimed tracemalloc peak (excludes prebuilt fixture bytes/native allocations; not RSS). Each process has 90s CPU/wall and 512MiB AS limits. The extended repeated ordinary-tag 4MiB memory trace may take tens of seconds; original 30s timeout was documented, not counted as a pass. Never run quadratic baseline beyond 32KiB on malicious families. Read the result status: malformed grammar can fail early by policy, rather than complete extraction.

## Semantics and limitations
One forward scanner, no DOM/stack/attribute list. Tags capped8192 chars, names64, entities35, first title1024, text12000; input within V14 4MiB decoded byte bound. Script/style raw content suppressed through matching own close or EOF, case-insensitive; nested openings ignored, self-closing raw tags conservatively suppress. Comments ignored; unterminated comments suppress remainder. Incomplete/overlong ordinary tags and malformed closers fail non-citable. Quoted tag-like attributes do not start suppression. First title wins including empty; unclosed title retains bounded text; entities decoded once, overlong malformed references literal; Unicode whitespace normalized. Safe ordinary outputs/provenance unchanged; extreme/malformed compatibility deliberately stricter. Large valid attributes may refuse.

V13/V14 protections unchanged. No hard deadline across synchronous DNS/TLS init/parsing, no process RSS ceiling, no full HTML5/CSS/JS rendering guarantee or sanitizer claim. Search's separate regex parser remains unchanged/uncertified for arbitrary adversarial pages. Required proxy retrieval fails closed. V14 IncompleteRead masking, calculator exhaustion, unsupported claims, zero-citation approval, live retrieval/TLS/billing/deployment remain unresolved. Muse has not audited V15 yet.
