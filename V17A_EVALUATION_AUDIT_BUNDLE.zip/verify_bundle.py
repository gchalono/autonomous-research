from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile
root=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((root/'MANIFEST.json').read_bytes())==(root/'MANIFEST.sha256').read_text().split()[0]
m=json.loads((root/'MANIFEST.json').read_text());listed={x['path'] for x in m['files']}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'MANIFEST.json','MANIFEST.sha256'}
assert listed==actual
for x in m['files']:assert sha((root/x['path']).read_bytes())==x['sha256'],x['path']
c=json.loads((root/'CHANGES.json').read_text())
with tempfile.TemporaryDirectory(prefix='v17a-patch-') as t:
 tree=Path(t)/'tree';shutil.copytree(root/'baseline_repository',tree)
 subprocess.run(['git','apply','--check',str(root/'V17A_COMPLETE.patch')],cwd=tree,check=True)
 subprocess.run(['git','apply',str(root/'V17A_COMPLETE.patch')],cwd=tree,check=True)
 for f,h in c['current_hashes'].items():assert sha((tree/f).read_bytes())==h and (tree/f).read_bytes()==(root/'current'/f).read_bytes(),f
print('Manifest, payload inventory, full hashes and patch reproduction verified.')
