# V17A independent audit bundle

Exact baseline: 8decbf0e15b5fd73bf462f35be4f3bff61c3755a. Evaluation apparatus only; actual engine citation/quote bindings enforced; synthetic mechanics labels, no production research accuracy measured. No independent human labels. No production code changed or committed.

current/ contains every authorized new file at exact relative paths, including three deliverable reports and evaluation code/tests/frozen oracles. V17A_COMPLETE.patch creates those paths on the exact baseline. BASELINE_STATE.json records every baseline tracked SHA; baseline_repository contains the complete baseline runtime, test suites and fixtures, except the irrelevant .env.example template (its metadata retained). CHANGES.json contains new-file inventory and complete digests. evaluation_v17a/ is a byte-identical convenience copy for portable replay. evidence/ contains exact commands, phase census, native V6 outputs, demonstration inputs/results and raw characterization/mutation evidence. Historical development collection error is disclosed separately. Full regression selected 679, passed677, skipped2, paid1 deselected; characterization separately has four strict expected AssertionErrors. Counts overlap across groups, not additive.

After extraction, verify every manifest entry and the manifest seal:

```bash
python verify_bundle.py
/path/to/project/venv/bin/python evaluation_v17a/replay.py harness --baseline-directory baseline_repository --output /tmp/v17a-harness
/path/to/project/venv/bin/python evaluation_v17a/replay.py full --baseline-directory baseline_repository --output /tmp/v17a-full
/path/to/project/venv/bin/python evaluation_v17a/replay.py characterization --baseline-directory baseline_repository --output /tmp/v17a-characterization
```

Existing dependencies only; exact versions are evidence/dependencies.txt. Full legacy suites require baseline_repository source/tests/audit fixture directories; evaluation snippets alone are insufficient. No credential/network setup is needed. The replay child verifies the offline guard, strips credentials, blocks Python socket/DNS/sendto and snapshot/source/canonical writes, permits only required disposable V6 evidence writes and retains results outside source. Timing controls bound test processes, not statistical precision; no production research timing/accuracy claim. Statistical CI examples are synthetic; actual study effect thresholds, human labels and budgets remain pending.

MANIFEST.json lists all payload hashes except itself and its seal; MANIFEST.sha256 seals MANIFEST.json. Those metadata files cannot contain their own hashes without circularity. A separate outer ZIP SHA-256 seals every ZIP byte. Exact frozen files can be authenticated only against independently trusted expected digests; self-consistent manifests do not establish authorship. No .env, key, database, cache, credential file or unrelated worktree artifact is included. No archive hash is embedded into itself.

See current/V17A_INDEPENDENT_AUDIT_HANDOFF.md for falsification tasks, current/V17A_EVALUATION_READINESS_REPORT.md for limitations and current/V17B_EXPERIMENT_PROTOCOL.md for unexecuted real-study prerequisites. No push or transfer authorization implied.
