# Acceptance report — V11 positional-only compatibility repair

**REGRESSION_FIXED: YES. ALL_ACCEPTANCE_GATES_PASSED: YES. SPENDING_GUARD_PRESERVED: YES. UNAUTHORIZED_CHANGES: NO. READY_FOR_INDEPENDENT_REAUDIT: YES.**

Current uncommitted work remains on `policy-validator-repair`, HEAD `c181afc440c2dd1e24aea4f537e22c0f80fb57a2`. This report updates the earlier selective-port acceptance record; its pre-V11 contents are preserved at `/tmp/positional-only-repair/ACCEPTANCE_REPORT.before.md`. Prior independent audit remains historical and unchanged; this correction has not yet received independent re-audit/commit approval.

## 1. Original defect and verified red state

SP-AUDIT-01: the executor treated the presence of a parameter named tool_choice as permission to send it by keyword. A valid legacy client with optional positional-only tool_choice failed at the final iteration before its method body ran.

Added `tests/test_forced_final_turn.py::test_C01_positional_only_choice_is_forced_positionally` to the existing compatibility-test file. Before any production edit, its real executor path failed with TypeError: positional-only arguments passed as keyword arguments, captured client invocations **0**, exit **1**. Expected failure matched the audit, not a fabricated assertion. After repair the identical test body passed, client invoked **once**, forced payload in the positional slot, exit **0**. The before/after test body was compared byte-for-byte via AST source extraction.

## 2. Minimal implementation correction

Only new production edit is `src/agents/executor.py::run_execution_native`. It preclassifies the inspected signature and chooses a positional/keyword/legacy argument shape **before** its single client invocation. The final trigger remains `turn == max_iterations - 1`; payload remains `{type:"function",name:"submit_report"}`. Non-final calls keep the original four arguments with no forced value.

| Signature | Corrected behavior |
|---|---|
| Positional-only choice immediately after existing four | Append forced choice positionally on final iteration |
| Positional-only choice after intervening defaulted positional parameters | Supply exactly those existing default objects, then the forced choice; default identity/semantics preserved |
| Positional-only choice behind a required intervening parameter | Do not invent an argument; retain four-argument call and its existing unsupported-signature failure |
| Positional-or-keyword choice not already occupied by the four legacy arguments | Supply forced choice by keyword |
| Keyword-only choice | Supply forced choice by keyword |
| No explicit value parameter, but **kwargs accepted | Supply forced choice by keyword |
| No support / uninspectable signature | Preserve four-argument call; do not guess |
| Name tool_choice already occupied by one of the four legacy positional arguments | Preserve existing argument; do not overwrite or send a duplicate keyword |

Exception handling is unchanged. The only TypeError catch is still around signature inspection, before execution. There is **one** create_tool_response invocation in each existing iteration; no try-call-and-retry branch. An internal provider TypeError or other exception propagates without a compatibility retry. Call-count and exception-identity assertions verify this directly. Later executor iterations remain ordinary separately authorized attempts, not compatibility recovery calls.

## 3. Permanent regression coverage

Only test file changed: `tests/test_forced_final_turn.py`, now **15 cases**. Ten new cases; existing positional-or-keyword test strengthened with actual args/kwargs recording, no assertions weakened.

| Requirement | Evidence |
|---|---|
| C01 positional-only | Red before / green after; forced positional payload; one invocation |
| C02 positional-or-keyword | Existing forced-turn test now verifies four positional arguments + keyword choice |
| C03 keyword-only / C05 kwargs | Parameterized traced call verifies keyword payload and exactly one invocation |
| C04 no choice support | Existing old-shape test preserves four-argument bounded behavior |
| C06 internal TypeError / C07 other exception | Same original exception object propagates; one method invocation, no retry |
| C08 non-final / C09 final | Existing test verifies no choice keyword in first turns and exact final payload |
| C10 malformed final report | Invalid executive_summary type fails existing report validation; one client call and bounded AgentOutputError |
| Additional required edges | Defaulted intervening slot preserves object identity; required slot not guessed; uninspectable signature keeps legacy path; fourth legacy argument with ambiguous name is preserved |

Client-method invocation counts are not represented as SDK HTTP-attempt counts. Separate guarded tests use the actual executor/provider/SDK path with mocked external transport.

## 4. Executed offline commands and results

Tests ran on fresh Git exports overlaid with the **exact working-tree bytes**, before/after. Sources were hash-compared back to the working tree. The runner uses credential-free child environments, strips provider credentials at interpreter startup (including spawned workers), and blocks socket APIs/audit events. Writes to the real repository or canonical active policy/ledger are denied. Test ledgers remain isolated fixtures. Per group: 90s wall, 45s CPU, 1GiB address space, 16MiB file output. No network install, external/provider request or allowance activation.

Command format, run from the repository:

`python /tmp/positional-only-repair/run.py <group> <before|after> <pytest arguments>`

The wrapper invokes the existing venv Python and `/tmp/positional-only-repair/child.py` in the indicated isolated tree. Exact executed commands and independently collected case IDs/results are retained as `<group>_summary.json` and `<group>.log`.

| Group | Source | Pass | Fail | Skip | Xfail | Xpass | Deselected | Exit |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| red | before | 0 | 1 | 0 | 0 | 0 | 0 | 1 |
| green | after | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| compatibility | after | 15 | 0 | 0 | 0 | 0 | 0 | 0 |
| original27 | after | 27 | 0 | 0 | 0 | 0 | 0 | 0 |
| guarded11 | after | 11 | 0 | 0 | 0 | 0 | 0 | 0 |
| audit_adversarial | after | 24 | 0 | 0 | 0 | 0 | 0 | 0 |
| offline_regression | after | 337 | 0 | 2 | 0 | 0 | 1 | 0 |

Exact commands (executed in required order):

```bash
python /tmp/positional-only-repair/run.py red before tests/test_forced_final_turn.py::test_C01_positional_only_choice_is_forced_positionally -q -ra -p no:cacheprovider
python /tmp/positional-only-repair/run.py green after tests/test_forced_final_turn.py::test_C01_positional_only_choice_is_forced_positionally -q -ra -p no:cacheprovider
python /tmp/positional-only-repair/run.py compatibility after tests/test_forced_final_turn.py -q -ra -p no:cacheprovider
python /tmp/positional-only-repair/run.py original27 after tests/test_tool_protocol.py tests/test_json_fallback.py tests/test_forced_final_turn.py::test_forced_turn_yields_report_and_carries_forced_choice tests/test_forced_final_turn.py::test_stubborn_after_forcing_still_fails_exactly_as_before tests/test_forced_final_turn.py::test_old_shape_client_unaffected_at_cap tests/test_forced_final_turn.py::test_engine_stubborn_after_forcing_is_failed_execution tests/test_forced_final_turn.py::test_truncation_note_no_longer_claims_completeness -q -ra -p no:cacheprovider
python /tmp/positional-only-repair/run.py guarded11 after tests/test_guarded_partb_integration.py -q -ra -p no:cacheprovider
python /tmp/positional-only-repair/run.py audit_adversarial after /tmp/independent-selective-audit/adversarial/test_faults.py /tmp/independent-selective-audit/adversarial/test_legacy_signature.py -q -ra -p no:cacheprovider
python /tmp/positional-only-repair/run.py offline_regression after tests audit_v3/test_independent_guard.py audit_v4/test_v4_adversarial.py audit_v4/test_v4_review.py policy_v5/test_policy_validation.py policy_v6/test_v6_validator.py policy_v7/test_v7_policy.py policy_v7/followup/test_blocked_policy.py --audit-output /tmp/positional-only-repair/regression_evidence/v3 --policy-audit-output /tmp/positional-only-repair/regression_evidence -q -ra -p no:cacheprovider -k 'not test_live_end_to_end'
```

The original 27 cases are explicitly selected by their original nodes, not assumed from a changed test-file count. The 11 original guarded-dispatch cases are unchanged. Relevant independent audit tests reproduce all **24 cases passing**, including the previously failing real-inner-provider positional-only legacy case.

Full regression: **337 passed, 2 historical V5 pricing assertions skipped, 1 paid live test deselected**, exit 0. All old 327 passing node/outcome pairs remain present; exactly ten new passing cases were added. No collection errors, xfails or xpasses. The unchanged historical skips are not claimed as provider-price/account verification. Groups overlap: compatibility, original gates and audit additions must not be added to the full total as disjoint coverage.

## 5. Financial-control and scope evidence

- Preflight still precedes the same provider call; no new request, loop iteration or compatibility retry is introduced.
- Guarded SDK tests retain reserve-before-HTTP, exhausted/invalid model/endpoint/policy refusal, unknown-priced-tool rejection, conservative failure/usage handling and retry-disable checks. Independent audit cases additionally cover timeouts, task cancellation, concurrent admission and legacy paths. All pass.
- Existing `src/llm/provider.py` remains byte-identical to task start; the earlier selective provider port remains present, not overwritten. SDK max_retries=0 and redirect disabling are unchanged.
- Spending guard, policy validator, model contracts/config, search, engine, canonical draft and identity are byte-identical to task start. Policy is still draft, activation_ready=false, with no canonical active policy or spending ledger in repository or test snapshots.
- Exactly two task-start files changed: **src/agents/executor.py** and **tests/test_forced_final_turn.py**. The other 141 recorded files are unchanged. Existing unrelated untracked reports/evidence and prior uncommitted provider/test work remain preserved. Git HEAD/index unchanged; nothing committed or pushed.
- Updated acceptance report and derivative patch/test evidence are outside the working tree. No second test file, pricing allowance, guard setting or environment configuration was edited. Secret-indicator and whitespace checks were clean.

## 6. Review artifacts

- Repair-only diff against the recorded pre-repair working state: `/tmp/positional-only-repair/REPAIR_ONLY.patch`.
- Complete current selective port diff against c181afc: `/tmp/positional-only-repair/SELECTIVE_PORT_REPAIRED.patch`, also refreshed at `/tmp/selective-partb-port/SELECTIVE_PORT.patch` for the next audit.
- Previous selective patch preserved at `/tmp/positional-only-repair/SELECTIVE_PORT.before.patch`; previous acceptance report preserved separately. The prior audit's hashes/verdict describe that earlier state, not this repaired patch.
- `final_integrity.json`, before/after source hashes and all test logs under `/tmp/positional-only-repair/`.

The repair-only patch was applied to a copy of task-start authorized files and reproduced the current two bytesets. Complete patch and integrity hashes are recorded in final_integrity.json. These are review artifacts, not commits or authorization to spend.

## 7. Remaining limitations and next action

Clients with genuinely required extra arguments cannot be made four-argument-compatible without inventing values; such signatures retain their existing failure. Uninspectable or no-choice clients retain legacy behavior and may not support forced submission. Decorated/plugin callables with misleading signatures are not universally certified. No method-body TypeError is interpreted as a binding failure or retried.

Receive-side Pydantic validation and spending reservations remain intact, but API acceptance, account access/billing applicability, research-quality correctness and hard invoice guarantees are not established by these tests. Pre-existing SSRF, unbounded-download, calculator-resource, factual-prose coverage and zero-citation approval findings remain outside this repair. No unsafe logger/fallback/snapshot behavior was imported. This is readiness for **independent re-audit**, not live-test/deployment/commit authorization.

**REGRESSION_FIXED: YES**

**ALL_ACCEPTANCE_GATES_PASSED: YES**

**SPENDING_GUARD_PRESERVED: YES**

**UNAUTHORIZED_CHANGES: NO**

**READY_FOR_INDEPENDENT_REAUDIT: YES**

**NEXT_ACTION: Independently re-audit the repaired executor calling conventions and updated tests/test_forced_final_turn.py against the refreshed selective patch.**
