# Selective Part B re-audit bundle

Repository: gchalono/autonomous-research
Branch: policy-validator-repair
Baseline: c181afc440c2dd1e24aea4f537e22c0f80fb57a2
State: uncommitted selective port including V11 positional-only repair.

SELECTIVE_PORT.patch is the full combined diff against the baseline, including both new test files. REPAIR_ONLY.patch applies to the pre-positional-repair working state, not directly to the Git baseline. Current production files and tests retain repository-relative paths. baseline/ contains original production bytes; pre_positional_repair/ contains the two files immediately before V11. These are comparison copies, not extra changes to apply.

ACCEPTANCE_REPORT.md is current. INDEPENDENT_SELECTIVE_PORT_AUDIT.md is the previous audit of the pre-repair port; its REVISE verdict and hashes are historical, not a re-audit of V11. PREVIOUS_ACCEPTANCE_REPORT.md and PRE_POSITIONAL_SELECTIVE_PORT.patch preserve that older evidence. Evidence logs include the expected red-state failure and subsequent green results; groups overlap and must not be summed.

The current acceptance report refers to original /tmp paths; matching reports, patches and result logs are included here where applicable. No source was committed or pushed. No allowance is activated. This bundle is for independent re-audit, not authorization to spend, deploy, or merge.
