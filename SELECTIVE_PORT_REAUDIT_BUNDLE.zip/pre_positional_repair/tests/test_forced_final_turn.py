"""Step 3 tests: forced final turn for the native executor (F-A2-1),
plus the transcript-note wording fix (F-A2-2 wording only).

Forced tool_choice shape, confirmed from the installed SDK types
(openai/types/responses/tool_choice_function_param.py,
ToolChoiceFunctionParam: {"name": <str>, "type": "function"}):
{"type": "function", "name": "submit_report"}.
"""

import json

import pytest

from src.agents.common import AgentOutputError
from src.agents.executor import SUBMIT_REPORT_NAME, run_execution_native
from src.llm.provider import StubProvider, default_stub_behavior
from src.orchestration.engine import Orchestrator
from src.storage.database import Store
from src.tools.base import ToolRegistry
from tests.conftest import fake_fetch, fake_registry

VALID_REPORT = {
    "executive_summary": "Summary.",
    "findings": [],
    "claims": [],
    "sources": [],
    "limitations": [],
    "unresolved_dependencies": [],
}


def _msg(text):
    return {"type": "message", "role": "assistant",
            "content": [{"type": "output_text", "text": text}]}


def _submit(report):
    return {"type": "function_call", "call_id": "c-submit",
            "name": SUBMIT_REPORT_NAME,
            "arguments": json.dumps(report)}


class ObedientClient:
    """Prose normally; obeys a forced tool_choice with a valid report."""
    supports_native_tools = True

    def __init__(self):
        self.choices = []

    def create_tool_response(self, instructions, input_items, tools, model,
                             tool_choice="auto"):
        self.choices.append(tool_choice)
        if isinstance(tool_choice, dict):
            return [_submit(VALID_REPORT)], 100, 50
        return [_msg("still thinking")], 100, 50


class StubbornClient:
    """Ignores forcing entirely: prose on every turn."""
    supports_native_tools = True

    def __init__(self):
        self.choices = []

    def create_tool_response(self, instructions, input_items, tools, model,
                             tool_choice="auto"):
        self.choices.append(tool_choice)
        return [_msg("still thinking")], 100, 50


class OldShapeClient:
    """Pre-Step-3 4-argument shape: must keep working untouched."""
    supports_native_tools = True

    def __init__(self):
        self.calls = 0

    def create_tool_response(self, instructions, input_items, tools, model):
        self.calls += 1
        return [_msg("still thinking")], 100, 50


def _run(client, max_iterations=3):
    return run_execution_native(client, "gpt-5.4-mini", ["SPEC"],
                                ToolRegistry(),
                                max_iterations=max_iterations)


def test_forced_turn_yields_report_and_carries_forced_choice():
    client = ObedientClient()
    report = _run(client, max_iterations=3)
    assert report.executive_summary == "Summary."
    assert client.choices[0] == "auto"
    assert client.choices[1] == "auto"
    assert client.choices[2] == {"type": "function",
                                 "name": SUBMIT_REPORT_NAME}


def test_stubborn_after_forcing_still_fails_exactly_as_before():
    client = StubbornClient()
    with pytest.raises(AgentOutputError, match="did not finish within 3"):
        _run(client, max_iterations=3)
    assert client.choices[2] == {"type": "function",
                                 "name": SUBMIT_REPORT_NAME}


def test_old_shape_client_unaffected_at_cap():
    client = OldShapeClient()
    with pytest.raises(AgentOutputError, match="did not finish within 3"):
        _run(client, max_iterations=3)
    assert client.calls == 3


def test_engine_stubborn_after_forcing_is_failed_execution(settings, store):
    """Engine-level (b): stubborn prose after forcing ends FAILED_EXECUTION."""
    class EngineClient(StubProvider):
        supports_native_tools = True

        def __init__(self, behavior):
            super().__init__(behavior)
            self.native = StubbornClient()

        def create_tool_response(self, instructions, input_items, tools,
                                 model, tool_choice="auto"):
            return self.native.create_tool_response(
                instructions, input_items, tools, model,
                tool_choice=tool_choice)

    engine = Orchestrator(settings, store,
                          client=EngineClient(default_stub_behavior()),
                          registry=fake_registry(), fetch_fn=fake_fetch)
    pid = engine.create_project("probe objective")
    status = engine.run(pid)
    assert status["state"] == "FAILED"
    assert status["terminal_status"] == "FAILED_EXECUTION"


def test_truncation_note_no_longer_claims_completeness():
    from src.agents.executor import _capped_items
    spec = {"role": "user", "content": "SPEC"}
    rounds = [[{"type": "function_call_output", "call_id": "c1",
                "output": "x" * 200}]]
    capped = _capped_items(spec, rounds, max_chars=50)
    note = json.dumps(capped)
    assert "complete" not in note
    assert "may have been dropped" in note
