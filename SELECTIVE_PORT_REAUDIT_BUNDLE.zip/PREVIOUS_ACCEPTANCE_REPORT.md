# Selective Part B implementation acceptance

Implemented, uncommitted, on `policy-validator-repair` at baseline `c181afc440c2dd1e24aea4f537e22c0f80fb57a2`.

## Exact scope

Modified production files: `src/llm/provider.py`, `src/agents/executor.py` only. Added tests: `tests/test_forced_final_turn.py` (five archived cases, unchanged) and `tests/test_guarded_partb_integration.py` (eleven reviewed actual-dispatch cases, only filename changed). Production file SHA-256 values exactly match the independently reviewed V10 candidate.

Changes: free-form legacy schemas select JSON-object mode before dispatch; strict-viable schemas retain strict-first behavior; receive-side Pydantic validation remains unchanged. Optional Responses function choice reaches the guarded provider; native executor selects submit_report on its final existing iteration, preserving four-argument clients and existing preflight/accounting. Corrected both transcript notes/docstring so they do not promise latest-result retention. No blanket keyword stripping, raw error logger, search fallback/provenance, engine metadata or snapshot harness integration.

## Complete source diff

`SELECTIVE_PORT.patch` contains all four intended files including new tests. It was checked/applied to a fresh c181afc export outside the target and reproduced their current bytes exactly. `final_integrity.json` records scope, policy/guard preservation and secret scan. No other tracked file changed (139 preserved); earlier untracked work is untouched. No commit, stage or push was performed.

## Offline execution and exact results

Executed orchestration command from the repository:

```bash
python /tmp/selective-partb-port/run_acceptance.py
```

The runner exports baseline source to `/tmp/selective-partb-port/tree`, overlays only the four authorized working files, and verifies snapshot hashes match current working-tree source. It launches each command below with a clean child environment, provider credentials stripped at Python startup (also spawned workers), network/socket audit denial and no writable real-repository or canonical active policy/ledger paths. Limits per group: 90s wall time, 45s CPU, 1GiB address space, 16MiB file output. No dependency installation or external network request. Temporary reviewed ledgers are test fixtures, not production activation. Do not bypass the isolation runner to use live credentials.

### protocol_forced

Working directory: `/tmp/selective-partb-port/tree`

```bash
/workspace/autonomous-research/.venv/bin/python /tmp/selective-partb-port/pytest_child.py tests/test_tool_protocol.py tests/test_json_fallback.py tests/test_forced_final_turn.py -q -ra -p no:cacheprovider
```

Observed: {"passed": 27}; exit 0; wall 0.617 seconds. Log: `protocol_forced.log`.

### guarded_dispatch

Working directory: `/tmp/selective-partb-port/tree`

```bash
/workspace/autonomous-research/.venv/bin/python /tmp/selective-partb-port/pytest_child.py tests/test_guarded_partb_integration.py -q -ra -p no:cacheprovider
```

Observed: {"passed": 11}; exit 0; wall 1.219 seconds. Log: `guarded_dispatch.log`.

### offline_regression

Working directory: `/tmp/selective-partb-port/tree`

```bash
/workspace/autonomous-research/.venv/bin/python /tmp/selective-partb-port/pytest_child.py tests audit_v3/test_independent_guard.py audit_v4/test_v4_adversarial.py audit_v4/test_v4_review.py policy_v5/test_policy_validation.py policy_v6/test_v6_validator.py policy_v7/test_v7_policy.py policy_v7/followup/test_blocked_policy.py --audit-output /tmp/selective-partb-port/regression_evidence/v3 --policy-audit-output /tmp/selective-partb-port/regression_evidence -q -ra -p no:cacheprovider -k 'not test_live_end_to_end'
```

Observed: {"passed": 327, "skipped": 2}; exit 0; wall 6.202 seconds. Log: `offline_regression.log`.

Both required exact gates passed: **27 protocol/forced-turn cases** and **11 guarded-dispatch cases**. Final complete offline regression: **327 passed, 2 historical V5 skips, 1 paid live test deselected**. No failures, xfails or xpasses. These groups overlap; do not sum them. All previously passing baseline regression cases remained passing. The two V5 skips are unchanged historical pricing assertions with stale missing-evidence wording; they are not claimed passed and do not establish current provider/account pricing. No paid case ran.

## Financial-control evidence

- Spending guard, strict policy loader, model contracts, canonical draft and identity are byte-identical to baseline. Existing SDK max_retries=0, redirects disabled, canonical ledger checks and terminal SpendingBlocked propagation remain in the provider.
- Actual combined native executor → provider → guard → installed OpenAI SDK MockTransport observes a dispatching reservation before the forced HTTP request, with default tier and output cap. Its second forced request is denied before send.
- Missing ledger/reservation, unknown model/endpoint, unpriced hosted tool and retries=2 all cause zero mock HTTP sends. Schema error, model-not-found and missing usage each preserve conservative exposure and block fallback after exactly one attempt.
- Invalid received schema value still triggers validation/repair; exhausted capacity blocks its next attempt. Existing process/thread concurrency, restart/recovery, failed-call accounting and unknown-pricing regressions pass.
- The real policy remains `state:draft`, activation_ready=false, with the existing mini-only limits and unresolved applicable billing contract/account access. `projects/live_cost_policy.json` and `projects/bounded_spending.sqlite3` remain absent in working tree and tested snapshot. No allowance activation occurred.

## Remaining defects and boundaries

Unchanged pre-existing findings: SSRF/internal-address retrieval; response-size cap only after full download; calculator CPU/memory resource exposure; unsupported factual prose/claims escaping evidence coverage; substantive zero-citation reports potentially receiving approval. High network/compute issues and medium general evidence-integrity issues remain separately documented in PARTB_SOURCE_INTEGRATION_REVIEW.md. Unsafe Part B logging, fallback and snapshot behavior were excluded, not imported or repaired.

Ready for **independent code review** of this bounded port. Not deployment/live-test readiness or permission to spend. No push, merge, deployment, environment-setting change or paid/authenticated provider request.

SELECTIVE_PORT_COMPLETE: YES
ACCEPTANCE_GATES_PASSED: YES
SPENDING_GUARD_PRESERVED: YES
POLICY_STILL_INACTIVE: YES
READY_FOR_INDEPENDENT_REVIEW: YES
