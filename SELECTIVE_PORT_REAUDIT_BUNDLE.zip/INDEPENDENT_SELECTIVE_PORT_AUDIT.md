# Independent selective Part B port audit — V2

## 1. Executive verdict

**REVISE before commit.** The exact patch and all three reported test groups were independently reproduced, including the same test identifiers/outcomes. The changed executor/provider paths preserved the tested spending invariants. However, an independently authored compatibility test passes at baseline and fails on this port: the new shim mistakes a positional-only optional `tool_choice` parameter for a keyword-capable parameter.

**SP-AUDIT-01 — MEDIUM, CONFIRMED_EXECUTED, introduced by port:** valid legacy four-argument calls can fail on the last iteration with TypeError before the provider is invoked (`src/agents/executor.py:163–178`). This is a bounded interface regression, not a demonstrated financial bypass. The declared backward-compatibility behavior is incomplete; a small correction and regression test are required before ACCEPT. No implementation was changed by this audit.

Independently reproduced: **27 passed**, **11 passed**, and **327 passed /2 skipped /1 paid case deselected**. Independent additional adversarial group: **23 passed**. Separate before/after compatibility test: **baseline 1 passed; port 1 failed**. These groups overlap or address different source revisions; do not sum them into a success total.

The audit is about commit readiness only. It does not certify research quality, model/account access, provider billing contracts, live execution or deployment. Pre-existing security/research limitations are not relabeled port regressions or used as the reason for REVISE.

## 2. Repository and patch identity

Repository origin: `https://github.com/gchalono/autonomous-research.git` (no embedded credentials). Branch: `policy-validator-repair`. HEAD exactly `c181afc440c2dd1e24aea4f537e22c0f80fb57a2`; baseline object is available. The port exists **both** as uncommitted working changes and as the actual supplied evidence file `/tmp/selective-partb-port/SELECTIVE_PORT.patch`.

| Evidence | Independently calculated SHA-256 |
|---|---|
| SELECTIVE_PORT.patch | `a637e03bdf70dc0784c5ec289f44accfaebf4241a756b4d0b91441ef0cf6377f` |
| ACCEPTANCE_REPORT.md | `c0053703f9f387a0b5cabe4e10e28109f6924165bc5c2b34782f9f648ed3826e` |

Both required evidence files were present and read. Their statements were treated as claims, not authorization or proof. The independently captured working-file inventory, patch reproduction and executed tests establish the findings here. No external Git/provider/network request, install, commit, stage, push or deployment was made.

## 3. Exact changed-file inventory

Against HEAD, exactly two tracked production files change; exactly two new test files belong to this port:

| File | Classification | Current SHA-256 |
|---|---|---|
| src/llm/provider.py | Production | `f5946f0ae16e60044996bed9a14f122afbf9ccbb073c8deda280678e4a799484` |
| src/agents/executor.py | Production | `e62ae543960755fa49d1c7e8d3be1df09762d71f7331b81aca79bcf6d05a5758` |
| tests/test_forced_final_turn.py | New tests, five cases | `0d021699903b067a4f18448a1eeb94be82ffd619973b8c2492799dea0dfd4192` |
| tests/test_guarded_partb_integration.py | New tests, eleven cases | `6cf0b5f9cbf333c340cfe821af62e5fd3304468109f404d54df88d592529bce7` |

No tracked documentation/configuration/dependency/environment/search/engine/spending-guard/policy-validator/model-contract changes exist. The canonical budget draft and identity match the expected baseline. There were **570 untracked files before audit**, including the two expected tests and **568 pre-existing historical artifacts**. The latter comprise 18 top-level reports, archived audit/source-diff/test evidence under audit_v3/v4, live_test_v2, policy_v5/v6/v7 and repair_artifacts. They are not part of this port and were not applied, edited or interpreted as new implementation changes. Generated/ignored caches are not included in the port.

The only new repository file created by this audit is this report. Before-state tracked-byte hashes and full Git status are retained in `/tmp/independent-selective-audit/before_hashes.json` and `before_status.txt`; previous uncommitted work is preserved.

## 4. Patch reproducibility

Fresh disposable exports of the expected baseline were made at `/tmp/independent-selective-audit/baseline` and `port`. In `port`, the unchanged actual SELECTIVE_PORT.patch passed `git apply --check` and applied successfully. All **143 intended files** (141 tracked files plus two tests) then matched current working-tree bytes, not merely a count or a previously supplied hash. Thus the patch and current port represent the same change set. No source was reconstructed from report prose.

Patch: `a637e03bdf70dc0784c5ec289f44accfaebf4241a756b4d0b91441ef0cf6377f`. Reconciliation metadata: `/tmp/independent-selective-audit/identity.json`. The baseline copy is unchanged c181afc; the port copy differs only by the supplied patch before isolated adversarial tests are added outside it. No production correction was applied to either audited implementation.

## 5. Independent test reproduction

All application execution used fresh, bounded, credential-free child processes. Only PATH/locale/timezone values were inherited; Python child startup strips API/token/secret/password/credential variables, including spawned workers. Socket resolution/connect/send audit events and socket APIs are denied. A blocking self-check executes before pytest import. Writes to the real repository and canonical active policy/ledger paths in both copies are denied; fixtures use their own temporary ledgers. Tests do not invoke deployment/environment management. No dummy-key-only isolation assumption was used.

Per group: **90s wall timeout, 45s CPU, 1GiB address space, 16MiB file-output limit**. Installed Python 3.12.14, OpenAI 3.41.0, httpx2 2.16.0, Pydantic 2.14.1 and pytest 9.2.0 were reused offline. The isolation driver/collector were independently constructed, not accepted from the earlier report.

| Group / source | Classification | Initial collected | Selected | Pass | Fail | Skip | Xfail/Xpass | Deselected | Collection errors | Exit |
|---|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
| reproduced27 / port | REPRODUCED | 27 | 27 | 27 | 0 | 0 | 0/0 | 0 | 0 | 0 |
| reproduced11 / port | REPRODUCED | 11 | 11 | 11 | 0 | 0 | 0/0 | 0 | 0 | 0 |
| reproduced327 / port | REPRODUCED | 330 | 329 | 327 | 0 | 2 | 0/0 | 1 | 0 | 0 |
| adversarial_final / port | Independent additions | 23 | 23 | 23 | 0 | 0 | 0/0 | 0 | 0 | 0 |
| legacy_baseline / baseline | Baseline control | 1 | 1 | 1 | 0 | 0 | 0/0 | 0 | 0 | 0 |
| legacy_port / port | Confirmed new regression | 1 | 1 | 0 | 1 | 0 | 0/0 | 0 | 0 | 1 |

The 27-case gate is exactly `tests/test_tool_protocol.py`, `tests/test_json_fallback.py`, `tests/test_forced_final_turn.py`. The 11-case gate is exactly `tests/test_guarded_partb_integration.py`. Each executed node ID/outcome was compared with the prior result JSON; **both complete sets match**, as does the full regression's node/outcome set. Identifiers and comparisons are retained in `<group>.json` and `<group>_case_comparison.json` below the audit root. A matching count alone was not accepted.

Regression includes the new two test files, spending/concurrency/error cases, V3/V4 offline cases, V5/V6 policy regressions and V7/mini draft cases. The two V5 skips are historical unconditional pricing-evidence skips with stale missing-rate wording, not passing provider/account verification. `tests/test_integration.py::test_live_end_to_end` was explicitly deselected. No hidden failures, xfails, xpasses or collection errors occurred in the reproduced groups.

Exact execution wrapper from the repository: `python /tmp/independent-selective-audit/run.py <group> <tree> <pytest arguments>`. It invokes the existing venv interpreter with `/tmp/independent-selective-audit/child.py`, in the indicated disposable tree and sanitized environment. Actual commands:

```
python /tmp/independent-selective-audit/run.py reproduced27 port tests/test_tool_protocol.py tests/test_json_fallback.py tests/test_forced_final_turn.py -q -ra -p no:cacheprovider
python /tmp/independent-selective-audit/run.py reproduced11 port tests/test_guarded_partb_integration.py -q -ra -p no:cacheprovider
python /tmp/independent-selective-audit/run.py reproduced327 port tests audit_v3/test_independent_guard.py audit_v4/test_v4_adversarial.py audit_v4/test_v4_review.py policy_v5/test_policy_validation.py policy_v6/test_v6_validator.py policy_v7/test_v7_policy.py policy_v7/followup/test_blocked_policy.py --audit-output /tmp/independent-selective-audit/regression/v3 --policy-audit-output /tmp/independent-selective-audit/regression -q -ra -p no:cacheprovider -k 'not test_live_end_to_end'
python /tmp/independent-selective-audit/run.py adversarial_final port /tmp/independent-selective-audit/adversarial/test_faults.py -q -ra -p no:cacheprovider
python /tmp/independent-selective-audit/run.py legacy_baseline baseline /tmp/independent-selective-audit/adversarial/test_legacy_signature.py -q -ra -p no:cacheprovider
python /tmp/independent-selective-audit/run.py legacy_port port /tmp/independent-selective-audit/adversarial/test_legacy_signature.py -q -ra -p no:cacheprovider
```

Full logs, exact interpreter commands, limits, node IDs, timings and exit codes: `/tmp/independent-selective-audit/<group>.log`, `.json`, `_summary.json`. Initial 19-case adversarial run passed; four focused schema/shim cases were then added, and the final 23-case group passed. Neither adversarial runs nor repeated/overlapping reproduction groups are counted as extra regression coverage totals.

## 6. Spending-guard call-path analysis

Source trace verified against the changed implementation:

1. `run_execution_native` selects model supplied by caller, builds bounded conversation/tool definitions and enters one existing iteration (`executor.py:152–168`). New forcing occurs only in the last permitted slot, not a separate post-loop call.
2. Existing cost_cb preflight runs before the provider (`:169–171`). Its Settings-based estimate is a heuristic, not the authoritative cumulative reservation.
3. The shim decides whether to add tool_choice (`:161–178`). Its positional-only handling is defective (SP-AUDIT-01); standard keyword-capable and old four-argument cases reach the normal provider.
4. `OpenAIProvider.create_tool_response` builds the native request with selected tools/choice (`provider.py:303–325`). Structured `complete` computes strict schema and chooses json_object for free-form legacy objects (`:209–233`). JSON-mode instruction suffix remains.
5. Both flow through `_request`, canonical/type checks and `guard.invoke_openai` (`provider.py:291–298`). Explicit SpendingBlocked catches at `:234–235,327–328` prevent reinterpretation as schema/model fallback.
6. Guard checks real SDK endpoint/operation/retries/redirects (`spending.py:284–294`), allowed request keys, priced model, tool type, byte/input/output bounds and policy (`:296–335`). Unknown or unsupported values reject before HTTP.
7. `reserve` checks individual/cumulative/aggregate capacity in the SQLite transaction and rejects an outstanding request (`:203–225`). `begin_dispatch` transitions only a valid reserved row (`:227–233`). The real HTTP transport is called only afterward (`:336–340`).
8. Actual provider construction sets `max_retries=0` and redirects off (`provider.py:201–202`). Installed SDK default is two, but is overridden, and transport validation rejects a poisoned retries=2 client before send. One SDK call was not assumed to equal one attempt without these checks.
9. Usage/model/tier checks and settlement run before returning output (`spending.py:344–354`). Exceptions retain uncertain exposure (`:341–343,241–261`), and missing/excess usage freezes. No refund is assumed. A BaseException cancellation leaves dispatching exposure retained; a later request rejects pending capacity.
10. Output items reach native argument/final-report validation; cost_cb records completed usage (`executor.py:183–233`). Schema-invalid results cannot erase the reservation. Any repair/fallback must get fresh admission; it is not authorized by the earlier request.

**CONFIRMED_EXECUTED:** independent HTTP handlers asserted a real SQL `dispatching` row and the expected full reservation before handling bytes. The audit instantiated the actual OpenAIProvider constructor and verified retry/redirect configuration before attaching MockTransport. No spending-guard method, `_request`, reserve or settlement was mocked. Only external HTTP behavior and canonical fixture paths were replaced.

Financial-policy files and model contracts are unchanged from baseline. Real policy remains `state:draft`, identity activation_ready=false; active canonical policy/ledger are absent. The real mini policy's 4096-byte/128-output/330634-micro-USD limitations and unresolved account/billing terms were not widened by the synthetic tests or certified as a hard invoice cap.

## 7. Adversarial fault-injection results

Each entry below was **CONFIRMED_EXECUTED** in the fresh audit fixture. Production entry points, actual guard/SQLite and installed SDK were exercised; only MockTransport responses/failures, a harmless tool callback and isolated policy paths were injected. Synthetic audit policy: full reservation **12,256 micro-USD** per admitted attempt, USD $1 maximum; no real allowance. Rows distinguish setup calls from new sends.

| ID | Entry / injected failure | Required invariant and observed result | HTTP transport |
|---|---|---|---|
| A01 | Native executor, max_iterations=1, sufficient capacity | Preflight then actual forced provider request; handler sees dispatching reservation, default tier/output cap; valid final report returned | 1, after reserve |
| A02 | Native forced turn after one call exhausts fixture aggregate cap | Subsequent attempt raises SpendingBlocked, no new send; first reservation retained | 1 setup; **0 new** |
| A03 | Native executor with unapproved model | Reject before reservation/transport | 0 |
| A04 | Real SDK unknown base URL; public guarded client extra_body override (2 cases) | Both reject, no alternate endpoint/option escape | 0 each |
| A05 | Native executor, MockTransport throws before any response | SDK error becomes terminal financial block; full reservation retained, next call denied | 1 total |
| A06 | SDK ReadTimeout after possible send | Same conservative exposure; no unsupported refund or hidden SDK retry | 1 total |
| A07 | Actual Orchestrator.cancel requested before run, real provider attached | Engine cancellation gate terminates before handler/preflight/provider | 0 |
| A08 | MockTransport raises asyncio.CancelledError during request | Signal propagates; real ledger remains dispatching with full reservation; next attempt denied as unreconciled | 1 total |
| A09 | Native function_call calculate with empty invalid expression | Argument model rejects; tool callback never runs; iteration ends with AgentOutputError, no follow-up beyond bound | 1 reserved request; 0 tool executions |
| A10 | submit_report with executive_summary list instead of string | ExecutionReport validation rejects; no approved report or unauthorized follow-up | 1 reserved request |
| A11 | Actual constructor verified zero retries, then SDK poisoned to retries=2 | Transport guard refuses before HTTP, independent of documentation | 0 |
| A12 | Allowed model returns 404, unapproved fallback configured | Ambiguous first charge retained; no fallback send or unknown-model authorization | 1 total |
| A13 | Old four-argument adapter around real guarded provider | Successful legacy call, default auto choice, one normal reservation | 1 |
| A14 | Missing/malformed/draft isolated policy (3 cases) | Actual provider entry rejects; no implicit policy/ledger creation | 0 each |
| A15 | Two actual executor/provider instances compete while first HTTP is held by bounded event | Second is atomically denied while first is dispatching; retained aggregate stays under cap; first completes normally | 1 total |

These cover the 15 scenarios in **18 parameterized cases**. Five supplementary cases make the final passing group 23: deterministic/nonmutating constraint preservation; free-form receive validation with sufficient capacity for two independently reserved invalid responses; keyword-only, **kwargs and uninspectable client signatures (three shapes). The receive-validation test ends with AgentOutputError after exactly two authorized, settled calls, so a budget rejection is not masking whether Pydantic actually ran.

Separate **SP-AUDIT-01** positional-only case is not included among the 23 passes: same test code passes on baseline and fails on port (section 9). It causes no confirmed unaccounted billing; Python rejects argument binding before the inner provider/transport.

Cancellation scope is explicit: A07 tests the public project flag before run; A08 injects a task-cancellation signal at the transport. Neither proves remote work was cancelled or that synchronous calls are forcibly interrupted. Existing project flag polling is cooperative at outer engine-loop boundaries (`engine.py:99–104,287–306`); intra-loop flag responsiveness is a pre-existing limitation, not newly fixed or fully assessed here.

## 8. Schema-contract assessment

**CONFIRMED_STATIC / CONFIRMED_EXECUTED:** the strict transformer body is unchanged; no Part B blanket keyword removal was imported. Current minimum/minLength constraints and literal property names `minimum`/`format` remain intact; representative transformation is deterministic and leaves the caller's schema untouched. Free-form legacy ExecutorStep requests now start in JSON-object mode, avoiding a known-incompatible strict description rather than pretending arbitrary arguments are an empty object.

Strict-viable schemas still prefer strict mode. Both format choices carry the same guarded model/input/output/endpoint restrictions. JSON instruction suffix is present; malformed output and invalid values still encounter existing JSON/Pydantic validation. Native invalid tool arguments and malformed final reports were independently rejected. Legacy tool arguments remain a generic dictionary plus tool-specific checks as before, not a newly promised native-equivalent validator.

Separate findings:

- **REQUEST_SCHEMA_COMPATIBLE:** supported request construction and forced function-choice **SDK serialization verified offline**. Real current-model API acceptance remains **UNVERIFIED**; vendor contract lookup/network was not allowed. Preserving a baseline keyword does not prove every model supports it.
- **RESPONSE_VALIDATED:** YES for tested application paths: call_agent validates its model; native executor validates argument/final-report models. Provider.complete by itself returns parsed JSON, not an independently supplied Pydantic instance; callers must retain those validation paths.
- **SEMANTICALLY_CORRECT:** UNVERIFIED. A structurally valid, empty-source synthetic report is test data, not research-quality evidence. Existing unsupported prose/zero-citation issues are not solved by forcing submit_report.

Pre-existing schema edge cases are not automatically fixed by this port. No new broad rewrite or vendor-keyword policy is authorized by this review.

## 9. Compatibility-shim assessment

Two related interface changes: base/real provider create_tool_response gains optional tool_choice defaulting auto (`provider.py:100–101,303–304`); executor uses inspect.signature to retain legacy four-positional-argument clients (`executor.py:161–178`). The shim is useful and should not be removed merely for style.

The old, keyword-only, **kwargs and inspection-unavailable shapes pass real guarded dispatch tests. Named keyword-capable clients receive forcing in the last existing slot; unsupported inspection falls back to the old four-argument call. Errors in actual provider calls must propagate without a blind retry.

### SP-AUDIT-01 reproduction

A valid legacy method can accept four required positional arguments plus an optional positional-only fifth argument:

```python
def create_tool_response(self, instructions, items, tools, model,
                         tool_choice="auto", /):
    return inner_guarded_provider.create_tool_response(
        instructions, items, tools, model)
```

At c181afc the native executor calls this with four positional arguments; it succeeds through the real guarded inner provider and one MockTransport request. The new code tests only whether the name `tool_choice` exists, sets `_accepts_choice=True` even though its Parameter.kind is POSITIONAL_ONLY, and calls it by keyword on the final iteration. Python raises:

`TypeError: ... got some positional-only arguments passed as keyword arguments: 'tool_choice'`

This is the original interface's valid four-argument behavior failing after the port. It is **not** an arbitrary fake guard or a deliberately bypassed validation gate. Baseline exit 0 /1 passed; port exit 1 /1 failed, using the same independently authored `/tmp/independent-selective-audit/adversarial/test_legacy_signature.py::test_positional_only_optional_choice_preserves_legacy_call` and real inner provider fixture.

**Minimal correction (not performed):** determine keyword capability before dispatch, accounting for Parameter.kind or validated signature binding. A POSITIONAL_ONLY named parameter without **kwargs must take the legacy four-argument path. Keep existing keyword-only, **kwargs, old-style and unavailable-signature behaviors. Do not implement “try keyword call, catch any TypeError, then call again”: the exception could arise after a real attempt and such recovery can duplicate side effects or hide an implementation error.

This affects nondefault legacy adapters, not the standard OpenAIProvider signature. It is a bounded MEDIUM interface regression and the sole new commit blocker found. The failure precedes inner provider dispatch, so it does not undermine the verified financial admission invariants. No shim retirement is presently warranted; a later documented interface migration could replace introspection, outside this correction.

## 10. Regression-suite quality

The reproduced suite meaningfully covers retained financial/policy behavior and core protocol paths, but raw count is not the assurance. All 27 original cases and 11 added cases are part of the larger 327 passes; they are not three disjoint totals. Exact node IDs/outcomes match the claims. The test list includes concurrency, failures/timeouts, usage, model/fallback restrictions, schema checks, policy-loader cases and the port tests.

Coverage weaknesses corrected by temporary audit tests:

- Five forced-turn tests mostly use client doubles; those verify loop/interface behavior but do not by themselves prove reserve-before-send.
- The 11 guarded-dispatch tests use the real guard/SDK route but construct provider instances with object.__new__, missing independent verification of production constructor configuration. Audit factory invokes the actual constructor and checks retries/redirects before replacing only transport.
- An invalid-response test ending in budget rejection alone could hide where validation failed. New test allows two repairs/calls and observes Pydantic/AgentOutputError, with both reservations retained.
- Cancellation and positional-only legacy shape were absent; the latter exposes a real new regression despite all 327 reported passes.

Mock fidelity limits: synthetic token/model/usage fields and temporary reviewed pricing declarations are not provider guarantees. SDK MockTransport exercises request serialization and actual resource/client retry logic without remote authentication; server enforcement/quality remains unknown. Bounded synchronization prevents an uncontrolled concurrency probe. Test processes cannot acquire live credentials/network through normal SDK paths; inactive canonical paths are protected from writes. Reported regressions and independent additions had no collection errors or uncontrolled timeouts.

Smallest missing permanent regression: the positional-only client test, plus retention of already-tested keyword-only/**kwargs/uninspectable behavior after a capability correction. No broad new suite or production financial change is needed.

## 11. Severity-ranked defect register

| ID | Severity / evidence | Affected source | Impact / introduced? | Minimal correction / required test |
|---|---|---|---|---|
| SP-AUDIT-01 | **MEDIUM — CONFIRMED_EXECUTED** | src/agents/executor.py, run_execution_native, :163–178 | New last-turn TypeError for valid four-argument legacy adapters with optional positional-only tool_choice. Baseline pass, port fail. Availability/compatibility impact; no confirmed unauthorized send. **Introduced by this port.** | Detect keyword-capable parameter kind/binding before call; otherwise use old path. Add test_positional_only_optional_choice_preserves_legacy_call, retaining 27/11 gates and supported signature behavior. |

**CRITICAL regressions: NONE CONFIRMED. HIGH new regressions: NONE CONFIRMED.** No demonstrated policy/reservation/SDK-retry bypass was found. The MEDIUM finding is still commit-blocking because compatibility is an explicit port requirement and a small direct correction is available.

Pre-existing SSRF, unbounded fetch size, calculator resource exposure, factual-claim coverage and zero-citation approval remain previously documented; they were not re-audited or relabeled introduced defects. Unsafe Part B logger/search fallback/snapshot behavior is absent from this selective diff. Those facts do not justify rejecting the otherwise bounded port or authorizing unrelated repairs.

## 12. Explicit limitations

Audit permits no external request, account probe, live API acceptance test, production mutation or paid execution; none occurred. Price declarations remain synthetic in adversarial fixtures; actual account terms/entitlements and invoice-level monetary guarantees are unverified. Current mini draft/account blockers were preserved.

Results apply to exact patch/source hashes, installed SDK versions and tested call paths. No claim of universal compatibility with every decorator/plugin implementation, immediate vendor-side cancellation, formal concurrency proof or research-quality correctness. A08 specifically tests cancellation after possible dispatch without assuming a refund. Full regression's two historical skipped assertions remain unverified, not counted passed.

The new failure occurs only for a supported-call-shape edge adapter, not the normal currently configured OpenAIProvider; its scope and severity are bounded accordingly. It is nevertheless an actual before/after regression, not a hypothetical API incompatibility. The untouched port is preserved for the implementer to correct under separate authorization.

## 13. Minimal required corrections

One correction before commit:

1. In `src/agents/executor.py::run_execution_native`, replace name-only keyword capability detection with a check that accounts for positional-only parameters (or safe pre-call signature binding). Preserve the four-argument fallback when keyword passing is invalid. No provider/guard/policy change is required.
2. Add the positional-only optional-choice case to necessary tests (for example `tests/test_forced_final_turn.py`), keeping the same successful baseline behavior and exercising a real guarded provider where feasible. Preserve existing keyword-only, **kwargs, four-argument and unavailable-signature cases.
3. Rerun the exact 27/11 gates and full offline command plus this regression, with an explained new case count if added. Require no unrelated changes and no lost receive validation/reservation controls. Do not suppress TypeError by retrying after calling the implementation.

No correction was applied here; no failing assertion was weakened, xfailed or removed. Temporary audit code lives under `/tmp/independent-selective-audit/`, not the working implementation/test suite.

## 14. Final commit-readiness decision

**REVISE**, not REJECT: the financial controls and receive-side checks held in the tested exact port, all claimed results reproduce, and the required repair is small and local. **Not ready to commit** until SP-AUDIT-01 is corrected and its before/after regression passes. No implementation/commit/push/deployment/spending is authorized by this review.

The patch and acceptance report remain available, current port source/tests are unchanged by the audit, and the policy stays inactive. This audit creates only `INDEPENDENT_SELECTIVE_PORT_AUDIT.md` in the repository. Detailed commands/results and fault-injection source remain in the isolated audit directory.

**PATCH_INDEPENDENTLY_VERIFIED: YES**

**SPENDING_GUARD_INTACT: YES**

**CRITICAL_REGRESSIONS: NONE CONFIRMED**

**READY_TO_COMMIT: NO**

**FINAL_DECISION: REVISE**

**NEXT_ACTION: Correct keyword-capability detection in src/agents/executor.py and add test_positional_only_optional_choice_preserves_legacy_call as its acceptance regression.**
