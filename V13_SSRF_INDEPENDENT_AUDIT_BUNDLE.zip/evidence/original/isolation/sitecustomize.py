import os,sys,socket
for key in list(os.environ):
    if any(x in key.upper() for x in ('API_KEY','TOKEN','SECRET','PASSWORD','CREDENTIAL')):os.environ.pop(key,None)
def deny(*args,**kwargs):raise RuntimeError('AUDIT_OFFLINE_NETWORK_DENIED')
socket.socket.connect=deny;socket.create_connection=deny;socket.getaddrinfo=deny;socket.gethostbyname=deny

def audit(event,args):
    if event in ('socket.connect','socket.getaddrinfo','socket.gethostbyname','socket.sendto'):raise RuntimeError('AUDIT_OFFLINE_NETWORK_DENIED')
    if event=='open' and args and isinstance(args[0],(str,bytes)):
        p=os.path.abspath(os.fsdecode(args[0]));mode=args[1];flags=args[2] or 0
        writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        forbidden=p.startswith('/workspace/autonomous-research/') or any(p==f'/tmp/v13-evidence/tree/projects/{f}' for f in ('live_cost_policy.json','bounded_spending.sqlite3'))
        if writing and forbidden:raise RuntimeError('AUDIT_PRODUCTION_OR_CANONICAL_WRITE_DENIED')
sys.addaudithook(audit)
