import os,sys,json,socket
from pathlib import Path
sys.path.insert(0,os.getcwd())
assert not any(os.environ.get(k) for k in ('OPENAI_API_KEY','TAVILY_API_KEY'))
try:socket.create_connection(('example.invalid',443))
except RuntimeError as e:assert str(e)=='AUDIT_OFFLINE_NETWORK_DENIED'
else:raise AssertionError('network guard missing')
import pytest
class Census:
    def __init__(self):self.details=[];self.outcomes={};self.deselected=[];self.collection_errors=[]
    def pytest_deselected(self,items):self.deselected.extend(x.nodeid for x in items)
    def pytest_collectreport(self,report):
        if report.failed:self.collection_errors.append(report.nodeid)
    def pytest_runtest_logreport(self,report):
        if report.when=='call' or (report.when=='setup' and report.outcome!='passed'):
            result='xfailed' if report.skipped and hasattr(report,'wasxfail') else 'xpassed' if report.passed and hasattr(report,'wasxfail') else report.outcome
            self.outcomes[result]=self.outcomes.get(result,0)+1
            self.details.append({'nodeid':report.nodeid,'outcome':result})
    def pytest_sessionfinish(self,session,exitstatus):
        Path(os.environ['AUDIT_RESULTS']).write_text(json.dumps({'exit_code':exitstatus,'selected':session.testscollected,'initial_collected':session.testscollected+len(self.deselected),'outcomes':self.outcomes,'deselected':self.deselected,'collection_errors':self.collection_errors,'details':self.details},indent=2))
if __name__=='__main__':raise SystemExit(pytest.main(sys.argv[1:],plugins=[Census()]))
