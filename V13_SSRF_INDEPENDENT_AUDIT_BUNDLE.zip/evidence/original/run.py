import subprocess,sys,resource,os,json,time
from pathlib import Path
root=Path('/tmp/v13-evidence');name,tree=sys.argv[1:3];args=sys.argv[3:]
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
env.update(PYTHONPATH=str(root/'isolation'),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_RESULTS=str(root/(name+'.json')))
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(45,45));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
cmd=['/workspace/autonomous-research/.venv/bin/python',str(root/'child.py'),*args];start=time.monotonic()
with (root/(name+'.log')).open('w') as f:
 try:result=subprocess.run(cmd,cwd=root/tree,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90,preexec_fn=limits);code=result.returncode
 except subprocess.TimeoutExpired:code=124
summary={'name':name,'tree':tree,'command':cmd,'cwd':str(root/tree),'exit_code':code,'wall_seconds':round(time.monotonic()-start,3),'limits':'90s wall/45s CPU/1GiB AS/16MiB file','source':'exact independently reproduced selective patch' if tree=='port' else 'c181afc baseline'}
if (root/(name+'.json')).exists():summary.update(json.loads((root/(name+'.json')).read_text()))
(root/(name+'_summary.json')).write_text(json.dumps(summary,indent=2));print(name,code,summary.get('outcomes'),'selected',summary.get('selected'),'deselected',len(summary.get('deselected',[])),flush=True);print((root/(name+'.log')).read_text()[-1800:],flush=True)
