import io
import pytest
from src.tools.retrieval import fetch_url

def test_private_fetch_never_dispatches(monkeypatch):
    calls=[]
    def open_(req,timeout=30):
        calls.append(req.full_url)
        return io.BytesIO(b'<title>private</title>')
    monkeypatch.setattr('urllib.request.urlopen',open_)
    try: fetch_url('http://127.0.0.1/secret')
    except ValueError: pass
    assert calls==[]
