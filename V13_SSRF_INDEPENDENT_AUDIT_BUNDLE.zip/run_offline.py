"""Use installed dependencies only. Runs patched source in disposable directories."""
from pathlib import Path
import argparse,subprocess,sys,tempfile,shutil,os,json,hashlib,resource
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('group',choices=['ssrf','fetch','tools','full']);p.add_argument('--full-repository',type=Path);a=p.parse_args()
manifest=json.loads((root/'MANIFEST.json').read_text())
for x in manifest['files']:
    assert hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
with tempfile.TemporaryDirectory(prefix='v13-audit-') as tmp:
    tmp=Path(tmp);tree=tmp/'tree'
    if a.full_repository:
        tree.mkdir()
        archive=subprocess.check_output(['git','-C',str(a.full_repository),'archive','2cd30eba4bfe95bc224d317a8216c212840ac757'])
        subprocess.run(['tar','-x','-C',str(tree)],input=archive,check=True)
    else:
        if a.group=='full':p.error('full requires --full-repository CHECKOUT with the baseline Git object')
        shutil.copytree(root/'baseline_repository',tree)
    subprocess.run(['git','apply','--check',str(root/'V13_COMPLETE.patch')],cwd=tree,check=True)
    subprocess.run(['git','apply',str(root/'V13_COMPLETE.patch')],cwd=tree,check=True)
    for f,h in json.loads((root/'CHANGES.json').read_text())['current_hashes'].items():
        assert hashlib.sha256((tree/f).read_bytes()).hexdigest()==h,f
    groups={'ssrf':['tests/test_ssrf.py'],'fetch':['tests/test_tools.py::test_fetch_page_extracts_text'],
      'tools':['tests/test_tools.py','tests/test_orchestration.py','tests/test_recovery.py','tests/test_phase4.py'],
      'full':['tests','audit_v3/test_independent_guard.py','audit_v4/test_v4_adversarial.py','audit_v4/test_v4_review.py','policy_v5/test_policy_validation.py','policy_v6/test_v6_validator.py','policy_v7/test_v7_policy.py','policy_v7/followup/test_blocked_policy.py','--audit-output',str(tmp/'v3'),'--policy-audit-output',str(tmp/'policy'),'-k','not test_live_end_to_end']}
    env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
    env.update(PYTHONPATH=str(root/'offline_guard'),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_RESULTS=str(tmp/'results.json'),AUDIT_IMMUTABLE_ROOT=str(root))
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(45,45));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
    code=subprocess.run([sys.executable,str(root/'offline_child.py'),*groups[a.group],'-q','-ra','-p','no:cacheprovider'],cwd=tree,env=env,timeout=90,preexec_fn=limits).returncode
    if (tmp/'results.json').exists():print((tmp/'results.json').read_text())
    sys.exit(code)
