# V13 SSRF independent audit bundle

Baseline: gchalono/autonomous-research, policy-validator-repair, 2cd30eba4bfe95bc224d317a8216c212840ac757. Implementation remains uncommitted. This package is audit evidence, not authorization to execute network requests or activate spending.

- V13_COMPLETE.patch: complete baseline diff, including new module, 54-case SSRF test file and report.
- current/: exact modified/new files, preserving repository-relative paths.
- baseline_production/: exact old versions of modified production files; safe_http.py is new and has no original version.
- baseline_repository/: baseline Python runtime, selected existing fetch/tool/orchestration tests, fixtures and dependency/test config. Unchanged supporting source is explicitly included for standalone execution, not additional V13 modifications.
- evidence/: final 54 SSRF, 1 existing fetch, 23 tool/orchestration, 391-pass full regression results; groups overlap. Two documented V5 skips, one paid test deselected. Original red reproduction and runner/isolation retained.
- CHANGES.json: exact scope/current hashes. MANIFEST.json: every other archive entry's SHA-256 and size. MANIFEST.sha256: manifest hash. The external .zip.sha256 sidecar hashes the complete archive; an archive cannot contain its own final hash without self-reference.
- environment.json: dependency versions and safe environment description (no environment-variable dump).

Use Linux/Python with preinstalled dependencies matching environment.json; no network installation. Extract into a disposable directory. Run with an existing environment's Python:

```
/path/to/python run_offline.py ssrf
/path/to/python run_offline.py fetch
/path/to/python run_offline.py tools
/path/to/python run_offline.py full --full-repository /path/to/existing/repository
```

The first three gates need no full checkout: the included baseline scaffold plus patch is sufficient. Full regression requires an existing full checkout containing the exact baseline Git object; the runner exports it read-only and applies the patch to temporary files. No fetch/clone is performed by the runner. Original pre-fix reproduction needs a disposable unpatched baseline and the original test_prefix.py (with urlopen mocked); it must fail before the patch. Raw logs in evidence/original use original absolute workspace paths. Portable runner above removes those path dependencies.

All groups strip credentials in child startup and deny socket DNS/connect/sendto using monkeypatches and Python audit hooks, including spawned Python workers. The SSRF tests replace networking with deterministic fake sockets/DNS and inspect actual connect arguments and HTTP Host/TLS configuration. Test fixtures create temporary synthetic policies/ledgers only. Canonical policy/ledger writes are denied. No live/internal/metadata connections. Run only in a disposable offline audit environment; Python hooks are not an OS sandbox against malicious test code.

Important evidence correction: original *_summary.json 'source' field was inherited from an earlier runner and says c181afc baseline. It is a stale label, not the V13 source identity. The verified V13 baseline is 2cd30eba..., exact current bytes/hashes are CHANGES.json, and the packaged portable replay checks those bytes. Original evidence is preserved without alteration.

Proxy limitation: production refuses any inherited HTTP/HTTPS/ALL proxy, including CGI and NO_PROXY overrides. Required proxy connectivity is unavailable until an independently established proxy destination-enforcement contract exists. Test child environments are credential-free; no managed/global proxy configuration is modified or bypassed for actual network access.

Known separate defects: unbounded response download, calculator resource exhaustion, unsupported factual claims and zero-citation approval. No live API/billing/deployment readiness implied. See current/SSRF_REMEDIATION_REPORT.md for sink inventory, security policy, exact original commands, limits and handoff.
