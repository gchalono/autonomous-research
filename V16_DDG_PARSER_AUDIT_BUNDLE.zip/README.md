# V16 DDG parser — independent audit bundle

Repository gchalono/autonomous-research; exact baseline 35e45274a9f3b8c7c54d757081bf92ee1d714d8e. Implementation is uncommitted in isolated detached worktree. Only search.py production changed; new fixture/test/report. No V16 commit/push/remote synchronization, no deployment/spending/live requests. Muse has not audited V16.

## Layout and provenance
V16_COMPLETE.patch includes every authorized changed/new path. current/ exact repository paths; baseline_original/ original search.py. baseline_repository/ provides baseline runtime, all tests/audits/fixtures, JSON config, requirements/pytest config and README. Historical markdown and .env.example omitted as unrelated/sensitive-format payload; no env or DB/caches/Git objects. BASELINE_STATE_MANIFEST/MODIFIED_STATE_MANIFEST cover complete tracked-state metadata; CHANGES identifies payload omissions and exact changes. Full replay uses only included source and fixtures, no external checkout needed; optional --full-repository exports the exact local baseline Git object, never uncommitted files.

evidence/ includes raw actual before/after measurements, semantic before/new outputs, operation counts and complete tests/native evidence. Final after benchmarks bind to exact final search.py SHA. Superseded development-code after measurements excluded. Completed baseline records use immutable baseline-search.py bytes, verified against Git. The deliberately timed-out32KiB closed-title baseline case is included as a TIMEOUT record, not completion. No larger cubic-like baseline run: do not extrapolate absent rows into measurements. Inputs are finite, exact deterministic bytes under inputs/ and INPUT_MANIFEST.json; fixtures use seed20261029. Original wall/CPU medians, ranges and output/rejection status retained. All data from this task, not borrowed prior-audit timings.

MANIFEST.json hashes every payload including state/input manifests. MANIFEST.sha256 authenticates MANIFEST.json; the seal cannot self-list. External ZIP checksum covers both seal entries. Verify hashes before running anything.

## Offline execution
Use an existing compatible Linux Python environment (environment.json), no network installs. Extract in a disposable directory. The established guard/census are unchanged from approved V15 artifact; packaging controller adapts paths/baseline/groups only. Credentials stripped; real Python socket/DNS blocked; snapshot/canonical files protected; native V6 evidence allowed only in disposable paths. Python guards are not an OS sandbox for hostile arbitrary code. Use OS network isolation as well if desired.

```
/path/to/python run_offline.py ddg --output /tmp/v16-audit/ddg
/path/to/python run_offline.py tools --output /tmp/v16-audit/tools
/path/to/python run_offline.py ssrf --output /tmp/v16-audit/ssrf
/path/to/python run_offline.py bounded --output /tmp/v16-audit/bounded
/path/to/python run_offline.py html --output /tmp/v16-audit/html
/path/to/python run_offline.py full --output /tmp/v16-audit/full
/path/to/python run_benchmarks.py --output /tmp/v16-audit/benchmarks
/path/to/python run_benchmarks.py --extended --output /tmp/v16-audit/extended
```

Use --protect-repository CHECKOUT to protect a separate local checkout. Full reference528 passed,2 historical V5 skips,1 paid test deselected; DDG51, tools23, SSRF54, bounded43, HTML43. Groups overlap. Full suite's output contains complete log/census/teardown/native JSON; no fixture DB published. All stage/source checks independent of count references. Search/fetch selection is tests/test_tools.py (3 cases) and the tools group includes it. No max-pass count baked into pytest command.

Benchmark driver builds exact patched source, invokes real production fallback with finite body stub, retains guard and source-hash checks. Before closed-title/missing-snippet family capped16KiB; others<=64KiB. Extended after reaches4MiB; wide-Unicode4MiB is separate. Each child has90s CPU/wall,512MiB AS; three calibrated batches and separate traced peak. Never replay the known timed-out32KiB cubic-like case merely to confirm vulnerability. Trace excludes fixture/native allocations and is not RSS. Timing ratios are finite evidence, not asymptotic proof. To run logical operation instrumentation on a prepared patched source directory: python instrument.py PATCHED_TREE /tmp/v16-operations.json. Runtime wrappers only, no source rewrite; counts are logical spans/calls, not native instruction visits.

## Contract and limitations
One pending candidate, bounded128 stack/record IDs,50 results,1024 title/500 snippet/4096 URL,8192 tag/64 name/64 classes. Explicit record + matching effective parent required; legacy bare pairs must be adjacent except whitespace/comments. New titles clear stale state; ambiguous explicit records reject; missing snippets never fabricated. Duplicates/order and explicit empty fields preserved. Malformed token/depth/attribute input may fail whole search; successful records emitted only at closed snippets. Early maximum stops only after complete records; HTTP already fully bounded/fetched. Comments/script/style content skipped; entities decoded from <=35-character tokens, quoted attributes respected.

No live/captured DDG fixtures: semantic confidence is synthetic only. Direct href HTML entities decoded correctly (intentional extension); legacy double percent unquote and startswith('http') discovery filtering remain, not safe/public fetch validation. All actual source fetches still use unchanged V13/V14 protected transport. V15 lexer private helpers reused unchanged; future changes need joint regressions. Tavily/guard/tool bodies byte-identical; canonical policy inactive.

Remaining: hard end-to-end deadlines, IncompleteRead masking, required-proxy refusal, calculator exhaustion, unsupported claims, zero-citation approval, live retrieval/TLS and account/billing/deployment readiness. Size/format limits impose deliberate strictness. No formal universal O(N) or process-RSS claim. Read the remediation report and independently test association, cursor work and peak allocation before commit authorization.
