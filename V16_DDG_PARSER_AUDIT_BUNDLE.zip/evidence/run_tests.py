from pathlib import Path
import os,sys,subprocess,resource,json,time
E=Path('/workspace/scratch/v16-evidence');H=E/'harness';name=sys.argv[1];args=sys.argv[2:]
env={k:os.environ[k] for k in ('PATH','LANG','TZ') if k in os.environ};env.update(PYTHONPATH=str(H/'offline_guard'),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_RESULTS=str(E/(name+'.json')),AUDIT_WORK_ROOT=str(E),AUDIT_IMMUTABLE_ROOT=str(H),AUDIT_PROTECTED_REPO='/workspace/autonomous-research',TMPDIR=str(E/'tmp'))
(E/'tmp').mkdir(exist_ok=True)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(45,45));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
cmd=['/workspace/autonomous-research/.venv/bin/python',str(H/'offline_child.py'),*args];start=time.monotonic()
with (E/(name+'.log')).open('w') as f:
 try:r=subprocess.run(cmd,cwd=E/'tree',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90,preexec_fn=limits);code=r.returncode
 except subprocess.TimeoutExpired:code=124
summary={'command':cmd,'cwd':str(E/'tree'),'process_exit':code,'wall_seconds':time.monotonic()-start,'timeout':code==124}
if (E/(name+'.json')).exists():summary.update(json.loads((E/(name+'.json')).read_text()))
(E/(name+'_summary.json')).write_text(json.dumps(summary,indent=2));print(name,code,summary.get('outcomes'),'collected',summary.get('initial_collected'),'teardown_errors',len(summary.get('teardown_errors',[])),flush=True);print((E/(name+'.log')).read_text()[-1200:],flush=True);sys.exit(code)
