from pathlib import Path
import sys,importlib.util,time,statistics,tracemalloc,json,resource,platform,math,hashlib,os
ROOT=Path(__file__).resolve().parent;W=Path(os.environ['V16_SOURCE_TREE']);E=Path(os.environ['V16_EVIDENCE_ROOT']);sys.path.insert(0,str(W));mode,family,size,target=sys.argv[1:];size=int(size)
resource.setrlimit(resource.RLIMIT_CPU,(90,90));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
spec=importlib.util.spec_from_file_location('fixtures',W/'tests/ddg_v16_fixtures.py');fixtures=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixtures);page=fixtures.malicious(family,size) if family!='wideunicode' else '';body=page.encode()
if family=='wideunicode':body='🙂'.encode()+b'a'*(size-4);page=body.decode()
path=ROOT/'baseline_repository/src/tools/search.py' if mode=='before' else W/'src/tools/search.py';spec=importlib.util.spec_from_file_location('src.tools.v16_benchmark',path);m=importlib.util.module_from_spec(spec);source_digest=hashlib.sha256(path.read_bytes()).hexdigest();spec.loader.exec_module(m);m.read_public_url=lambda url:body

def invoke():
 try:r=m._search_duckduckgo('offline',50);return {'status':'completed','results':len(r)}
 except ValueError as e:return {'status':'ValueError','message':str(e),'results':0}
invoke();t=time.perf_counter();invoke();pilot=time.perf_counter()-t;batch=max(1,min(20000,math.ceil(.04/max(pilot,1e-7))));cpu=[];wall=[]
for _ in range(3):
 t=time.process_time();w=time.perf_counter()
 for j in range(batch):status=invoke()
 cpu.append((time.process_time()-t)/batch);wall.append((time.perf_counter()-w)/batch)
tracemalloc.start();invoke();current,peak=tracemalloc.get_traced_memory();tracemalloc.stop()
Path(target).parent.mkdir(parents=True,exist_ok=True);Path(target).write_text(json.dumps({'source_sha256':source_digest,'mode':mode,'family':family,'input_bytes':len(body),'input_chars':len(page),'candidate_openings':page.count('class="result__a"'),'cpu_median':statistics.median(cpu),'cpu_range':[min(cpu),max(cpu)],'wall_median':statistics.median(wall),'wall_range':[min(wall),max(wall)],'peak_python_bytes':peak,'result':status,'repetitions':3,'iterations_per_repetition':batch,'python':sys.version,'platform':platform.platform(),'memory_note':'Separate untimed traced call; excludes prebuilt input and native allocations.'},indent=2));print(mode,family,size,statistics.median(cpu),peak,status,flush=True)
