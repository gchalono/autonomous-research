"""Portable benchmark replay, no network; never run the cubic-like 32KiB baseline."""
from pathlib import Path
import argparse,tempfile,subprocess,shutil,os,sys,json,hashlib
root=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path);p.add_argument('--extended',action='store_true');args=p.parse_args();output=args.output.resolve();output.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='v16-benchmark-') as name:
 work=Path(name);tree=work/'tree';shutil.copytree(root/'baseline_repository',tree);subprocess.run(['git','apply',str(root/'V16_COMPLETE.patch')],cwd=tree,check=True)
 for f,h in json.loads((root/'CHANGES.json').read_text())['current_hashes'].items():assert hashlib.sha256((tree/f).read_bytes()).hexdigest()==h
 jobs=[]
 for family in ['openings','missing_close','near_class','malformed','whitespace','benign']:
  before=[2048,4096,8192,16384] if family=='openings' else [4096,8192,16384,32768,65536]
  after=[4096,8192,16384,32768,65536]+([262144,1048576,4194304] if args.extended else [])
  jobs.extend(('before',family,n) for n in before);jobs.extend(('after',family,n) for n in after)
 jobs.append(('after','wideunicode',4194304))
 for mode,family,size in jobs:
  env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ};env.update(PYTHONPATH=str(root/'offline_guard'),PYTHONDONTWRITEBYTECODE='1',AUDIT_WORK_ROOT=str(work),AUDIT_IMMUTABLE_ROOT=str(root),AUDIT_PROTECTED_REPO='',V16_SOURCE_TREE=str(tree),V16_EVIDENCE_ROOT=str(output))
  with (output/f'{mode}_{family}_{size}.log').open('w') as stream:
   try:r=subprocess.run([sys.executable,str(root/'benchmark_one.py'),mode,family,str(size),str(output/f'{mode}_{family}_{size}.json')],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=90);code=r.returncode
   except subprocess.TimeoutExpired:code=124
  if code:raise SystemExit(code)
  print(mode,family,size,'completed',flush=True)
