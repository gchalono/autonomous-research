"""Portable, credential-free audit replay. Uses existing dependencies only."""
from pathlib import Path
import argparse,subprocess,sys,tempfile,shutil,os,json,hashlib,resource
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('group',choices=['ddg','html','bounded','ssrf','fetch','tools','full']);p.add_argument('--full-repository',type=Path);p.add_argument('--output',type=Path);p.add_argument('--protect-repository',type=Path);a=p.parse_args()
for x in json.loads((root/'MANIFEST.json').read_text())['files']:
    assert hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
assert hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest()==(root/'MANIFEST.sha256').read_text().split()[0]
output=(a.output or Path.cwd()/'audit_replay_output'/a.group).resolve()
with tempfile.TemporaryDirectory(prefix='v16-audit-') as temp:
    tmp=Path(temp);tree=tmp/'tree';(tmp/'tmp').mkdir()
    if a.full_repository:
        tree.mkdir()
        archive=subprocess.check_output(['git','-C',str(a.full_repository),'archive','35e45274a9f3b8c7c54d757081bf92ee1d714d8e'])
        subprocess.run(['tar','-x','-C',str(tree)],input=archive,check=True)
    else:
        shutil.copytree(root/'baseline_repository',tree)
    subprocess.run(['git','apply','--check',str(root/'V16_COMPLETE.patch')],cwd=tree,check=True)
    subprocess.run(['git','apply',str(root/'V16_COMPLETE.patch')],cwd=tree,check=True)
    changes=json.loads((root/'CHANGES.json').read_text())
    for f,h in changes['current_hashes'].items():assert hashlib.sha256((tree/f).read_bytes()).hexdigest()==h,f
    # Full-copy legacy evidence is recreated, never confused with archived data.
    if (tree/'policy_v6').exists():
        for q in (tree/'policy_v6/case_evidence').glob('*.json'):q.unlink()
        q=tree/'policy_v6/validator_results.json'
        if q.exists():q.unlink()
    before={str(q.relative_to(tree)):hashlib.sha256(q.read_bytes()).hexdigest() for q in tree.rglob('*') if q.is_file()}
    groups={'ddg':['tests/test_ddg_parser.py'],'html':['tests/test_html_extraction.py'],'bounded':['tests/test_bounded_retrieval.py'],'ssrf':['tests/test_ssrf.py'],'fetch':['tests/test_tools.py::test_fetch_page_extracts_text'],
      'tools':['tests/test_tools.py','tests/test_orchestration.py','tests/test_recovery.py','tests/test_phase4.py'],
      'full':['tests','audit_v3/test_independent_guard.py','audit_v4/test_v4_adversarial.py','audit_v4/test_v4_review.py','policy_v5/test_policy_validation.py','policy_v6/test_v6_validator.py','policy_v7/test_v7_policy.py','policy_v7/followup/test_blocked_policy.py','--audit-output',str(tmp/'evidence/v3'),'--policy-audit-output',str(tmp/'evidence'),'-k','not test_live_end_to_end']}
    env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
    env.update(PYTHONPATH=str(root/'offline_guard'),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_RESULTS=str(tmp/'results.json'),TMPDIR=str(tmp/'tmp'),V14_MEASUREMENTS=str(tmp/'measurements'),AUDIT_WORK_ROOT=str(tmp),AUDIT_IMMUTABLE_ROOT=str(root),AUDIT_PROTECTED_REPO=str((a.protect_repository or a.full_repository).resolve()) if (a.protect_repository or a.full_repository) else '')
    def limits():
        resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(45,45));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
    cmd=[sys.executable,str(root/'offline_child.py'),*groups[a.group],'-q','-ra','-p','no:cacheprovider']
    try:
        result=subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=90,preexec_fn=limits);code=result.returncode;log=result.stdout+result.stderr
    except subprocess.TimeoutExpired as e:
        code=124;log='TIMEOUT\n'+str(e)
    output.mkdir(parents=True,exist_ok=True);(output/'pytest.log').write_text(log)
    if (tmp/'results.json').exists():shutil.copyfile(tmp/'results.json',output/'results.json')
    for dirname in ['measurements','evidence']:
        if (tmp/dirname).exists():shutil.copytree(tmp/dirname,output/dirname,dirs_exist_ok=True)
    if (tree/'policy_v6').exists():
        for q in [tree/'policy_v6/validator_results.json',*sorted((tree/'policy_v6/case_evidence').glob('*.json'))]:
            if q.exists():
                dest=output/q.relative_to(tree);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(q,dest)
    for f,h in before.items():assert hashlib.sha256((tree/f).read_bytes()).hexdigest()==h,f
    (output/'replay.json').write_text(json.dumps({'command':cmd,'process_exit':code,'baseline':changes['baseline'],'current_hashes':changes['current_hashes'],'original_snapshot_files_unchanged':True},indent=2))
    if (output/'results.json').exists():
        d=json.loads((output/'results.json').read_text());print(json.dumps({k:d[k] for k in ('exit_code','initial_collected','selected','outcomes','teardown_errors','collection_errors','internal_errors')}))
    print('process_exit:',code,'evidence:',output)
    sys.exit(code)
