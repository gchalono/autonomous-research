"""Test-only runtime wrappers; logical work spans, not CPU instruction counts."""
from pathlib import Path
import sys,json,weakref,importlib.util,hashlib
W=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/scratch/v16-worktree');target=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/workspace/scratch/v16-evidence/operations.json')
sys.path.insert(0,str(W));from src.tools import search as m
spec=importlib.util.spec_from_file_location('fixture',W/'tests/ddg_v16_fixtures.py');f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
metrics={};live=weakref.WeakSet();original_tag=m._tag;original_init=m._DDGText.__init__;original_reset=m._DDGParser.reset;original_scope=m._DDGParser.scope
class Search:
 def __init__(self,pattern,key):self.pattern,self.key=pattern,key
 def search(self,text,start=0,end=None):
  match=self.pattern.search(text,start,len(text) if end is None else end)
  metrics[self.key+'_calls']=metrics.get(self.key+'_calls',0)+1
  metrics[self.key+'_prefix']=metrics.get(self.key+'_prefix',0)+(match.start()-start+1 if match else (len(text) if end is None else end)-start)
  return match

def tag(text,start):
 out=original_tag(text,start);metrics['tag_calls']+=1;metrics['tag_span_chars']+=out[0]-start;return out

def init(self,cap):
 original_init(self,cap);live.add(self);metrics['buffers_created']+=1;metrics['max_live_buffers']=max(metrics['max_live_buffers'],len(live))

def reset(self):metrics['resets']+=1;return original_reset(self)
def scope(self):metrics['max_stack']=max(metrics['max_stack'],len(self.stack));metrics['max_record_ids']=max(metrics['max_record_ids'],len(self.record_titles));return original_scope(self)
m._tag=tag;m._DDGText.__init__=init;m._DDGParser.reset=reset;m._DDGParser.scope=scope
m._DDG_MARK=Search(m._DDG_MARK,'marker');m._DDG_ENTITY=Search(m._DDG_ENTITY,'entity');m._DDG_NONSPACE=Search(m._DDG_NONSPACE,'whitespace');m._RAW_END={k:Search(v,'raw_end') for k,v in m._RAW_END.items()}
rows=[]
for family in ['openings','missing_close','near_class','benign']:
 for size in [4096,8192,16384,32768,65536]:
  metrics={'tag_calls':0,'tag_span_chars':0,'buffers_created':0,'max_live_buffers':0,'resets':0,'max_stack':0,'max_record_ids':0}
  page=f.malicious(family,size)
  try:out=m._parse_ddg(page,50);status='completed'
  except ValueError:out=[];status='ValueError'
  assert metrics['tag_span_chars']<=len(page) and metrics['max_stack']<=128 and metrics['max_record_ids']<=128
  assert metrics['max_live_buffers']<=4
  rows.append({'family':family,'characters':len(page),'status':status,'output_count':len(out),**metrics})
target.write_text(json.dumps({'source_sha256':hashlib.sha256((W/'src/tools/search.py').read_bytes()).hexdigest(),'measurement':'Wrapper span/call counts and WeakSet live buffer identities; not instrumented engine/native character visits. No source edits.','rows':rows},indent=2));print('instrumentation cases',len(rows),'all structural bounds hold')
