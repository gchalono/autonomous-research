# V14 bounded retrieval — independent adversarial audit

Repository gchalono/autonomous-research; branch policy-validator-repair; exact committed V13 baseline 927dc73481e10e3152f9bf7247d4c37d09042879. V14 implementation remains uncommitted. Packaging has not changed source/tests or the canonical policy. This is audit evidence, not deployment/live-testing/spending authorization.

## Layout and scope
- V14_COMPLETE.patch: full exact diff, including new tests and report. Three paths only.
- current/: exact modified/new source/test/report, preserving repository-relative paths.
- baseline_original/: exact committed old safe_http.py (only modified production file).
- baseline_repository/: unchanged baseline runtime source, main.py, SSRF/retrieval/tool/orchestration tests and fixtures/config sufficient for focused replay. Supporting files are unchanged baseline, not extra V14 modifications.
- BASELINE_STATE_MANIFEST.json: full SHA-256 of every tracked baseline file. MODIFIED_STATE_MANIFEST.json: full state including V14 additions/overlay, excluding unrelated untracked files. Manifest metadata is complete even where unchanged baseline artifacts are not duplicated here.
- CHANGES.json: exact intended inventory and current full hashes.
- evidence/: original final logs, per-phase census, original harness and native evidence; per-case resource measurements from focused/full runs. Original absolute paths are historical context; portable runner has no fixed workspace paths.
- environment.json: dependency versions. pyproject.toml and requirements files retain repository dependency/test configuration.
- MANIFEST.json lists hashes and sizes of every payload entry, including both state manifests. MANIFEST.sha256 authenticates MANIFEST.json; it cannot hash itself. The external ZIP SHA-256 covers all entries, including this integrity pair.

## Offline replay
Use Linux/Python with existing dependencies compatible with environment.json. No network installation. Extract to a disposable directory. These commands verify manifest, recreate baseline + patch in temporary files, compare source hashes, strip credentials and deny real socket/DNS requests in Python children. Resource-limit tests fake the raw socket-file stream but execute real HTTPResponse framing and real zlib decoding. No API/internal/metadata contact occurs.

```
/path/to/venv/bin/python run_offline.py bounded --output /tmp/v14-replay/bounded
/path/to/venv/bin/python run_offline.py ssrf --output /tmp/v14-replay/ssrf
/path/to/venv/bin/python run_offline.py fetch --output /tmp/v14-replay/fetch
/path/to/venv/bin/python run_offline.py tools --output /tmp/v14-replay/tools
/path/to/venv/bin/python run_offline.py full --full-repository /path/to/existing/checkout --output /tmp/v14-replay/full
```

Expected independent gates: 43 V14, 54 SSRF, 1 fetch, 23 tools/orchestration; full 434 passes, 2 historical V5 skips, 1 paid live test deselected. Groups overlap. Focused gates need no full checkout. The full gate needs an existing checkout containing the exact baseline Git object: runner uses git archive, not that checkout's current files; no clone/fetch or paid call. Full baseline fixtures/audit sources must be available there. Full replay leaves V6 evidence writes enabled only in its disposable evidence locations, protects snapshot/original source and canonical policy/ledger, and retains all native evidence externally. Source/test assertions are never altered. Output holds logs, per-phase results, measurements and native V3/V4/V5/V6 JSON; no fixture databases are copied. Python guards protect these known tests, not a sandbox for running hostile arbitrary code; use OS-level network isolation for independent testing if desired.

Pre-fix reproduction: evidence/original/test_prefix.py runs against the unpatched baseline and intentionally fails, observing 2097152 bytes consumed despite advertised length 1, with resources closed. It is a fake-response demonstration, not a claim that real HTTPResponse ignores Content-Length. Final resource tests use real framing and counted unbuffered reads. Original runtime contracts inspected in evidence/original/transport-contract.txt.

## Limits and known gaps
Engineering defaults: 1MiB encoded body delivered, up to one additional overflow byte; 4MiB retained decompressed output, one-byte decoded probe; 2MiB total HTTP plaintext (headers, body, framing, prefetch and redirects), one-byte probe. These are not encrypted TLS/TCP wire-byte or RSS guarantees. Default inactivity 10s, cooperative monotonic budget 60s across the transport/redirect chain. Synchronous DNS, TLS-context initialization and downstream parsing cannot be preempted: TIME_LIMIT_ENFORCED remains PARTIAL. Never infer a hard total timeout from passing inactivity/deadline tests.

V13 SSRF checks remain intact; required proxy environments fail closed. gzip and zlib-wrapped deflate supported with bounded decompression; malformed, concatenated/trailing, raw-deflate, Brotli and stacked encodings reject. Existing 12000-character extraction cap is separate from byte security. No silent successful oversized HTML truncation. Size/time defaults are assumptions needing future authorized workload validation.

Still unresolved: hard total-duration/CPU control, calculator exhaustion, unsupported factual claims, zero-citation approval, live TLS/retrieval acceptance, provider/billing applicability and deployment readiness. Canonical policy remains draft/inactive. The V14 report is evidence-backed but independently unaudited; inspect code, raw counters, zlib limits, cleanup, timing gaps and preserved V13 boundary.
