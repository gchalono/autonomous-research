from pathlib import Path
import subprocess,sys,os,resource,json,time
root=Path('/tmp/v14-evidence');group=sys.argv[1];args=sys.argv[2:]
env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ') if k in os.environ}
env.update(PYTHONPATH=str(root/'isolation'),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',AUDIT_RESULTS=str(root/(group+'.json')),TMPDIR=str(root/'tmp'),V14_MEASUREMENTS=str(root/'measurements'/group))
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(45,45));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
cmd=['/workspace/autonomous-research/.venv/bin/python',str(root/'child.py'),*args];start=time.monotonic()
with (root/(group+'.log')).open('w') as f:
 try:result=subprocess.run(cmd,cwd=root/'tree',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90,preexec_fn=limits);code=result.returncode
 except subprocess.TimeoutExpired:code=124
summary={'command':cmd,'cwd':str(root/'tree'),'process_exit':code,'wall_seconds':round(time.monotonic()-start,3),'timeout':code==124}
if (root/(group+'.json')).exists():summary.update(json.loads((root/(group+'.json')).read_text()))
(root/(group+'_summary.json')).write_text(json.dumps(summary,indent=2))
print(group,'exit',code,'outcomes',summary.get('outcomes'),'collected',summary.get('initial_collected'),'teardown_errors',len(summary.get('teardown_errors',[])),flush=True)
print((root/(group+'.log')).read_text()[-1400:]);sys.exit(code)
