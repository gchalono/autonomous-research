import pytest
from src.tools import safe_http as net

def test_dishonest_length_is_bounded(monkeypatch):
    monkeypatch.setattr(net,'getproxies',lambda:{})
    for k in list(__import__('os').environ):
        if k.lower().endswith('_proxy'):monkeypatch.delenv(k)
    state={'raw_bytes':0,'response_closed':False,'connection_closed':False}
    class Response:
        status=200
        def getheader(self,name):return '1' if name.lower()=='content-length' else None
        def read(self,amount=None):
            remaining=2*1024*1024-state['raw_bytes'];size=remaining if amount is None else min(remaining,amount)
            state['raw_bytes']+=size;return b'x'*size
        def close(self):state['response_closed']=True
    class Conn:
        def __init__(self,*a):pass
        def request(self,*a,**k):pass
        def getresponse(self):return Response()
        def close(self):state['connection_closed']=True
    monkeypatch.setattr(net,'_PinnedConnection',Conn)
    try:net.read_public_url('http://93.184.216.34/')
    except ValueError:pass
    print(state)
    assert state['response_closed'] and state['connection_closed']
    assert state['raw_bytes']<=1024*1024+1
